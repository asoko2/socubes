            <div class="container">
                <div class="col-md-8 col-md-offset-2" >
                    <div id="main-slider">
                        <?php foreach($unggul as $rubik) { ?>
                            <div class="item">
                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>"><img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar)  ?>" alt="" class="img-responsive"></a>
                            </div>
                        <?php } ?>
                    </div>
                    <!-- /#main-slider -->
                </div>
            </div>

            <!-- *** ADVANTAGES HOMEPAGE ***
 _________________________________________________________ -->
            <div id="advantages">

                <div class="container">
                    <div class="same-height-row">
                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-heart"></i>
                                </div>

                                <h3><a href="#">Pelanggan No. 1</a></h3>
                                <p>Kepuasan pelanggan adalah keutamaan kami</p>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-tags"></i>
                                </div>

                                <h3><a href="#">Harga Terjangkau</a></h3>
                                <p>Menyediakan rubik berkualitas tinggi dengan harga terjangkau.</p>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-thumbs-up"></i>
                                </div>

                                <h3><a href="#">100% kepuasan terjamin</a></h3>
                                <p>Barang tidak sesuai pesanan gratis return.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                </div>
                <!-- /.container -->

            </div>
            <!-- /#advantages -->

            <!-- *** ADVANTAGES END *** -->

            <!-- *** HOT PRODUCT SLIDESHOW ***
 _________________________________________________________ -->
            <div id="hot">

                <div class="box">
                    <div class="container">
                        <div class="col-md-12">
                            <h2>Produk terbaru dari SoCubes <?php $id = $this->session->userdata('id_transaksi'); 
                                if($this->session->userdata('id_transaksi')==''){
                                    echo $id['id_transaksi'];
                                    }else{
                                        echo $id;
                                        } ?></h2>
                            <h2><?php echo $this->session->userdata('id'); ?>
                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="product-slider">
                        <?php foreach($rubik_baru as $rubik) { ?>
                            <div class="item">
                                <div class="product">
                                    <div class="flip-container">
                                        <div class="flipper">
                                            <div class="front">
                                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>">
                                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="" class="img-responsive">
                                                </a>
                                            </div>
                                            <div class="back">
                                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>">
                                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="" class="img-responsive">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>" class="invisible">
                                        <img src="<?php echo base_url() ?>assets/obaju/img/product1.jpg" alt="" class="img-responsive">
                                    </a>
                                    <div class="text">
                                        <h3><a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>"><?php echo $rubik->nama_produk ?></a></h3>
                                        <p class="price">Rp <?php echo $rubik->harga ?></p>
                                    </div>
                                    <!-- /.text -->
                                </div>
                                <!-- /.product -->
                            </div>
                        <?php } ?>

                    </div>
                    <!-- /.product-slider -->
                </div>
                <!-- /.container -->

            </div>
            <!-- /#hot -->

            <!-- *** HOT END *** -->
