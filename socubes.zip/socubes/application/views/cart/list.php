<div class="container">

                <div class="col-md-9" id="basket">

                    <div class="box">

                        <h1>Keranjang Belanja</h1>
                        <p class="text-muted">Anda punya 
                        <?php if($this->session->userdata('id_transaksi')!=''){
                            $id = $this->session->userdata('id_transaksi');
                            $hitung = $this->cart_model->hitung($this->session->userdata('id_transaksi'));
                            echo $hitung;
                        }else{
                            echo '0';
                        } ?> item di keranjang</p>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th colspan="2">Produk</th>
                                        <th>Jumlah</th>
                                        <th>Harga</th>
                                        <th colspan="2">Total</th>
                                        <th colspan="2"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($cart as $cart) { 
                                        $rubik = $this->rubik_model->detail($cart->id_produk); ?>
                                    <tr>
                                        <td>
                                            <a href="#">
                                                <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar); ?>" alt="White Blouse Armani">
                                            </a>
                                        </td>
                                        <td><a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk); ?>"><?php echo $rubik->nama_produk; ?></a>
                                        </td>
                                        <td style="text-align: center;">
                                            <?php echo $cart->jumlah; ?>
                                        </td>
                                        <td>Rp <?php echo $rubik->harga; ?></td>
                                        <td>Rp <?php $total = $rubik->harga * $cart->jumlah;
                                                echo $total; ?></td>
                                        <td>
                                            <?php echo form_open(base_url('cart/plus/'.$cart->id_cart)); ?>
                                                <input type="hidden" name="id_produk" value="<?php echo $rubik->id_produk?>">
                                                <input type="hidden" name="jumlah" value="<?php echo $cart->jumlah ?>">
                                                <button type="submit" class="btn-sm btn-default"><i class="fa fa-plus"></i></button>
                                            <?php echo form_close(); ?>
                                        </td>
                                        <td>
                                            <?php echo form_open(base_url('cart/min/'.$cart->id_cart)); ?>
                                                <input type="hidden" name="id_produk" value="<?php echo $rubik->id_produk?>">
                                                <input type="hidden" name="jumlah" value="<?php echo $cart->jumlah ?>">
                                                <button type="submit" class="btn-sm btn-default"><i class="fa fa-minus"></i></button>
                                            <?php echo form_close(); ?>
                                        </td>
                                        <td>
                                            <?php include('batal.php'); ?>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="4">Total</th>
                                        <th colspan="4">Rp <?php echo $count; ?></th>
                                    </tr>
                                </tfoot>
                            </table>

                        </div>
                        <!-- /.table-responsive -->

                        <div class="box-footer">
                            <div class="pull-left">
                                <a href="<?php echo base_url() ?>" class="btn btn-default"><i class="fa fa-chevron-left"></i> Lanjut belanja</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo base_url('checkout') ?>" class="btn btn-primary">Proses checkout <i class="fa fa-chevron-right"></i></a>
                            </div>
                        </div>

                    </div>
                    <!-- /.box -->

                </div>
                <!-- /.col-md-9 -->

            </div>
            <!-- /.container -->
