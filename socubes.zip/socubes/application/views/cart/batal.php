<a href="#" data-toggle="modal" data-target="#login-modal<?php echo $cart->id_cart ?>" class="btn-sm btn-default"><i class="fa fa-trash-o"></i></a>
<div class="modal fade" id="login-modal<?php echo $cart->id_cart ?>" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
    <div class="modal-dialog modal-sm">

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="Login">Batalkan pesanan <?php echo $rubik->nama_produk ?> ?</h4>
            </div>
            <div class="modal-body">
                <p class="text-center">
                <?php echo form_open('cart/batal'); ?>
                    <input type="hidden" name="id_produk" value="<?php echo $rubik->id_produk ?>">
                    <input type="hidden" name="stok" value="<?php echo $cart->jumlah ?>">
                    <input type="hidden" name="id_cart" value="<?php echo $cart->id_cart ?>">
                    <button type="submit" class="btn btn-primary">Ya</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tidak</button>
                <?php echo form_close(); ?>
                </p>
            </div>
        </div>
    </div>
</div>