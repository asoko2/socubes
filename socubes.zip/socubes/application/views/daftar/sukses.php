<div class="container">

    <div class="col-md-6 col-md-offset-3">
        <div class="box">
            <h1>Registrasi Berhasil</h1>

            <p class="lead">Silahkan login <a href="<?php echo base_url('login') ?>">di sini</a> untuk melanjutkan</p>
        </div>
    </div>

</div>
<!-- /.container -->