<div class="container">

    <div class="col-md-6 col-md-offset-3">
        <div class="box">
            <h1>Registrasi</h1>

            <p class="lead">Belum terdaftar menjadi pelanggan kami?</p>
            <p>Silahkan registrasi untuk dapat menikmati fitur-fitur kami.</p>
            <p class="text-muted">Jika anda mempunyai pertanyaan seputar rubik atau website ini, silahkan <a href="<?php echo base_url('kontak') ?>">hubungi kami</a>, kami akan memberi respon secepatnya.</p>

            <hr>
            <?php echo validation_errors('<div class="alert alert-warning">','</div>');
            ?>
            <?php echo form_open(base_url('daftar')) ?>
                <div class="form-group">
                    <label for="name">Nama Depan<sup>*</sup></label>
                    <input type="text" name="nama_depan" class="form-control" id="name" value="<?php echo set_value('nama_depan') ?>">
                </div>
                <div class="form-group">
                    <label for="name">Nama Belakang</label>
                    <input type="text" name="nama_belakang" class="form-control" id="name" value="<?php echo set_value('nama_belakang') ?>">
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin &nbsp;&nbsp; : &nbsp;&nbsp;</label>
                    <label class="radio-inline"><input type="radio" name="jk" value="L" required> Laki-laki</label>
                    <label class="radio-inline"><input type="radio" name="jk" value="P" required> Perempuan</label>
                </div>
                <div class="form-group">
                    <label for="email">Email<sup>*</sup></label>
                    <input type="text" name="email" class="form-control" id="email" value="<?php echo set_value('email') ?>">
                </div>
                <div class="form-group">
                    <label for="name">Username<sup>*</sup></label>
                    <input type="text" name="username" class="form-control" id="name" value="<?php echo set_value('username') ?>">
                </div>
                <div class="form-group">
                    <label for="password">Password<sup>*</sup></label>
                    <input type="password" name="password" class="form-control" id="password">
                </div>
                <div class="form-group">
                    <label for="name">Ulangi Password<sup>*</sup></label>
                    <input type="password" name="password2" class="form-control" id="name">
                </div>
                <div class="form-group">
                    - <sup>*</sup> harus diisi
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-user-md"></i> Daftar</button>
                </div>
            <?php echo form_close() ?>
        </div>
    </div>
</div>
<!-- /.container -->