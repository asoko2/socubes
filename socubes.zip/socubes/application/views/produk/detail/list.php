<div class="container">

    <div class="col-md-3">
        <!-- *** MENUS AND FILTERS ***
_________________________________________________________ -->
        <div class="panel panel-default sidebar-menu">

            <div class="panel-heading">
                <h3 class="panel-title">Kategori</h3>
            </div>

            <div class="panel-body">
                <ul class="nav nav-pills nav-stacked category-menu">
                    <li>
                        <?php 
                        $kategori = $this->kategori_model->listing();
                        foreach($kategori as $kategori) { ?>
                        <li <?php if($kategori->id_kategori == $rubik->id_kategori){echo 'class="active"';} ?>>
                        <a href="<?php echo base_url('produk/kategori/'.$kategori->slug_kategori) ?>"><?php echo $kategori->nama_kategori ?></a>
                    </li>
                    <?php } ?>
                    </li>
                </ul>

            </div>
        </div>

        <!-- *** MENUS AND FILTERS END *** -->

    </div>

    <div class="col-md-9">

        <div class="row" id="productMain">
            <div class="col-sm-6" style="height: 400px;background-color: white">
                <div>
                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="" class="img-responsive">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="box">
                    <h1 class="text-center"><?php echo $rubik->nama_produk ?></h1>
                    <h5 class="text-center">Stok : <?php echo $rubik->stok ?></h5>
                    <p class="goToDescription"><a href="#details" class="scroll-to">Lihat detail produk</a>
                    </p>
                    <p class="price">Rp <?php echo $rubik->harga ?></p>

                    <?php 
                        if($this->session->userdata('id')==''){
                            ?>
                            <p class="text-center buttons">
                                <label class="btn">Jumlah</label>
                                <input type="number" name="jumlah" class="btn form-sm" min="1" max="<?php echo $rubik->stok ?>" required>
                                <input type="hidden" name="id_transaksi" value="">
                                <input type="hidden" name="id_produk" value="">
                                <?php include('login_modal.php');?>
                            </p>
                            <?php
                        }else{
                            if($this->session->userdata('id_transaksi')==''){
                                $idbaru = $this->cart_model->idbaru();
                                
                                if($idbaru=='0'){
                                    $id = $idbaru+1;
                                }else{
                                    $id = $idbaru->id_transaksi+1;
                                }

                                echo form_open('cart/baru');
                            ?>
                            <p class="text-center buttons">
                                <label class="btn">Jumlah</label>
                                <input type="number" name="jumlah" class="btn form-sm" min="1" max="<?php echo $rubik->stok ?>" required>
                                <input type="hidden" name="id_transaksi" value="<?php echo $id ?>">
                                <input type="hidden" name="id_produk" value="<?php echo $rubik->id_produk ?>">
                                <input type="submit" class="btn btn-primary" value="Beli">             
                            </p>
                            <?php echo form_close(); } else { 
                                //$id = $this->session->userdata('id_transaksi');
                                echo form_open('cart/tambah'); ?>
                            <p class="text-center buttons">
                                <label class="btn">Jumlah</label>
                                <input type="number" name="jumlah" class="btn form-sm" min="1" max="<?php echo $rubik->stok ?>" required>
                                <input type="hidden" name="id_transaksi" value="<?php $id=$this->session->userdata('id_transaksi');    if($this->session->userdata('id_transaksi')==''){
                                    echo $id['id_transaksi'];
                                    }else{
                                        echo $id;
                                        } ?>">
                                <input type="hidden" name="id_produk" value="<?php echo $rubik->id_produk ?>">
                                <input type="submit" class="btn btn-primary" value="Beli">
                            </p>
                            <?php echo form_close(); } ?>

                    <?php } ?>

                        


                </div>

            </div>

        </div>


        <div class="box" id="details">
            <p>
                <h4>Detail Produk</h4>
                <p><?php echo $rubik->deskripsi ?></p>
                <?php $id = $this->session->userdata('id_transaksi');
                    if($this->session->userdata('id_transaksi')==''){
                        echo $id['id_transaksi'];
                        }else{
                            echo $id;
                            } ?>
                <hr>
        </div>

        <div class="row same-height-row">
            <div class="col-md-3 col-sm-6">
                <div class="box same-height">
                    <h3>Produk yang mungkin anda suka</h3>
                </div>
            </div>

            <?php foreach($sama as $sama) { ?>
            <div class="col-md-3 col-sm-6">
                <div class="product same-height">
                    <div class="flip-container">
                        <div class="flipper">
                            <div class="front">
                                <a href="detail.html">
                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$sama->gambar) ?>" alt="" class="img-responsive">
                                </a>
                            </div>
                            <div class="back">
                                <a href="detail.html">
                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$sama->gambar) ?>" alt="" class="img-responsive">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="detail.html" class="invisible">
                        <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$sama->gambar) ?>" alt="" class="img-responsive">
                    </a>
                    <div class="text">
                        <h3><?php echo $sama->nama_produk ?></h3>
                        <p class="price">Rp <?php echo $sama->harga ?></p>
                    </div>
                </div>
                <!-- /.product -->
            </div>
            <?php } ?>

        </div>

    </div>
    <!-- /.col-md-9 -->
</div>
<!-- /.container -->