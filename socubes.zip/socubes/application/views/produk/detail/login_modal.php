<a href="#" data-toggle="modal" data-target="#login-modal1" class="btn btn-primary">Beli</a>
<div class="modal fade" id="login-modal1" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
    <div class="modal-dialog modal-sm">

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="Login">Login terlebih dahulu</h4>
            </div>
            <div class="modal-body">
                <?php echo form_open('login/direct') ?>
                    <div class="form-group">
                        <input type="text" name="username" class="form-control" id="email-modal" placeholder="username">
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" id="password-modal" placeholder="password">
                    </div>
                        <input type="hidden" name="a" value="<?php echo $this->uri->segment(1) ?>">
                        <input type="hidden" name="b" value="<?php echo $this->uri->segment(2) ?>">
                        <input type="hidden" name="c" value="<?php echo $this->uri->segment(3) ?>">
                        <input type="hidden" name="d" value="<?php echo $this->uri->segment(4) ?>">
                    <p class="text-center">
                        <button class="btn btn-primary"><i class="fa fa-sign-in"></i>Masuk</button>
                    </p>

                <?php echo form_close() ?>

                <p class="text-center text-muted">Belum terdaftar ?</p>
                <p class="text-center text-muted"><a href="register.html"><strong>Daftar sekarang</strong></a></p>

            </div>
        </div>
    </div>
</div>