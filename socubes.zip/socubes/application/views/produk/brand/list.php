    <div class="col-md-9">
        <div class="box">
            <h1><?php echo $brand_data->nama_brand ?></h1>
        </div>

        <div class="row products">

            <?php foreach($rubik as $rubik) { ?>
            <div class="col-md-4 col-sm-6">
                <div class="product daftar-produk">
                    <div class="flip-container">
                        <div class="flipper">
                            <div class="front">
                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>">
                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/').$rubik->gambar ?>" alt="" class="daftar" >
                                </a>
                            </div>
                            <div class="back">
                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>">
                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/').$rubik->gambar ?>" alt="" class="daftar">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>" class="invisible">
                        <img src="<?php echo base_url('assets/upload/gambar/thumbs/').$rubik->gambar ?>" alt="" class="daftar">
                    </a>
                    <div class="text">
                        <h3><a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>"><?php echo $rubik->nama_produk ?></a></h3>
                        <p class="price">Rp <?php echo $rubik->harga ?></p>
                        <p class="buttons">
                            <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>" class="btn btn-default">View detail</a>
                            <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Beli</a>
                        </p>
                    </div>
                    <!-- /.text -->
                </div>
                <!-- /.product -->
            </div>
            <?php } ?>
    </div>
        <br><br><br><br><br>
        <div class="pages">
            <?php
                echo $this->pagination->create_links();
            ?>
        </div>


    <!-- /.col-md-9 -->
</div>
<!-- /.container -->