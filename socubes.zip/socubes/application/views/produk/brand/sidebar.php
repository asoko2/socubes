<div class="container">
    <div class="col-md-3">
        <!-- *** MENUS AND FILTERS ***
    _________________________________________________________ -->
        <div class="panel panel-default sidebar-menu">

            <div class="panel-heading">
                <h3 class="panel-title">Brand</h3>
            </div>

            <div class="panel-body">
                <ul class="nav nav-pills nav-stacked category-menu">
                    <?php 
                        $brand = $this->brand_model->listing();
                        foreach($brand as $brand) { ?>
                    <li <?php if($brand->slug_brand == $slug_brand){echo 'class="active"';} ?>>
                        <a href="<?php echo base_url('produk/brand/'.$brand->slug_brand) ?>"><?php echo $brand->nama_brand ?></a>
                    </li>
                    <?php } ?>
                </ul>

            </div>
        </div>

        <!-- *** MENUS AND FILTERS END *** -->
    </div>