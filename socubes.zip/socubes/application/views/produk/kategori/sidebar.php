<div class="container">
    <div class="col-md-3">
        <!-- *** MENUS AND FILTERS ***
    _________________________________________________________ -->
        <div class="panel panel-default sidebar-menu">

            <div class="panel-heading">
                <h3 class="panel-title">Kategori</h3>
            </div>

            <div class="panel-body">
                <ul class="nav nav-pills nav-stacked category-menu">
                    <?php 
                        $kategori = $this->kategori_model->listing();
                        foreach($kategori as $kategori) { ?>
                    <li <?php if($kategori->slug_kategori == $slug_kategori){echo 'class="active"';} ?>>
                        <a href="<?php echo base_url('produk/kategori/'.$kategori->slug_kategori) ?>"><?php echo $kategori->nama_kategori ?></a>
                    </li>
                    <?php } ?>
                </ul>

            </div>
        </div>

        <!-- *** MENUS AND FILTERS END *** -->
    </div>