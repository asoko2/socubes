 <div class="container">
    <div class="col-md-8 col-md-offset-2">
        <?php
            echo validation_errors('<div class="alert alert-warning">','</div>');

            if($this->session->flashdata('sukses')){
                echo '<div class="alert alert-warning">';
                echo $this->session->flashdata('sukses');
                echo '</div>';
            }
        ?>
    </div>
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">                            
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#home" data-toggle="tab">Profil</a>
                            </li>
                            <li class=""><a href="#profile" data-toggle="tab">Edit Profil</a>
                            </li>
                            <li class=""><a href="#messages" data-toggle="tab">Ubah Password</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade active in" id="home">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td>Nama</td>
                                            <td>:</td>
                                            <td><?php echo $user->nama_depan.' '.$user->nama_belakang ?></td>
                                        </tr>
                                        <tr>
                                            <td>Username</td>
                                            <td>:</td>
                                            <td><?php echo $user->username ?></td>
                                        </tr>
                                        <tr>
                                            <td>Email</td>
                                            <td>:</td>
                                            <td><?php echo $user->email ?></td>
                                        </tr>
                                        <tr>
                                            <td>Jenis Kelamin</td>
                                            <td>:</td>
                                            <td><?php if($user->jk=='L'){echo 'Laki-laki';}else{echo 'Perempuan';}; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="profile">
                                <br>
                                <?php echo form_open('profil/ubah/'); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Username</label>
                                                <input type="text" name="username" class="form-control" value="<?php echo $user->username ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="text" name="email" class="form-control" value="<?php echo $user->email ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Nama Depan</label>
                                                <input type="text" name="nama_depan" class="form-control" value="<?php echo $user->nama_depan; echo set_value('nama_depan'); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Nama Belakang</label>
                                                <input type="text" name="nama_belakang" class="form-control" value="<?php echo $user->nama_belakang ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                    <label>Jenis Kelamin    :   </label>
                                        <label class="radio-inline"><input type="radio" name="jk" value="L" <?php if($user->jk=='L'){echo 'checked';} ?>> Laki-laki</label>
                                        <label class="radio-inline"><input type="radio" name="jk" value="P" <?php if($user->jk=='P'){echo 'checked';} ?>> Perempuan</label>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-warning">Ubah</button>
                                    </div>
                                <?php echo form_close() ?>                                
                            </div>
                            <div class="tab-pane fade" id="messages">
                            <br>
                                <?php echo form_open('profil/ubahpassword')?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password Lama</label>
                                            <input type="password" name="password_lama" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password Baru</label>
                                            <input type="password" name="password_baru" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Ulangi Password</label>
                                            <input type="password" name="konfir_pass" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-warning">Ganti Password</button>
                                        </div>
                                    </div>
                                </div>
                                <?php echo form_close() ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
<!-- /.container -->