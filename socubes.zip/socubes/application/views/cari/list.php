<div class="container">

    <div class="col-md-12">

        <div class="box info-bar">
            <div class="row">
                <div class="col-sm-12 col-md-4 products-showing">
                    <h4>Hasil pencarian dari : <?php echo $this->input->post('nama') ?></h4>
                </div>
            </div>
        </div>

        <div class="row products">
            <?php foreach($rubik as $rubik) { ?>
            <div class="col-md-3 col-sm-4">
                <div class="product">
                    <div class="flip-container">
                        <div class="flipper">
                            <div class="front">
                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>">
                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="" class="img-responsive">
                                </a>
                            </div>
                            <div class="back">
                                <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>">
                                    <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="" class="img-responsive">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="detail.html" class="invisible">
                        <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="" class="img-responsive">
                    </a>
                    <div class="text">
                        <h3><a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>"><?php echo $rubik->nama_produk ?></a></h3>
                        <p class="price">Rp <?php echo $rubik->harga ?></p>
                        <p class="buttons">
                            <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>" class="btn btn-default">View detail</a>
                            <a href="<?php echo base_url('produk/detail/'.$rubik->slug_produk) ?>" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Beli</a>
                        </p>
                    </div>
                    <!-- /.text -->
                </div>
                <!-- /.product -->
            </div>
            <?php } ?>

        </div>
        <!-- /.products -->

        <div class="pages">

            <ul class="pagination">
                <li><a href="#">&laquo;</a>
                </li>
                <li class="active"><a href="#">1</a>
                </li>
                <li><a href="#">2</a>
                </li>
                <li><a href="#">3</a>
                </li>
                <li><a href="#">4</a>
                </li>
                <li><a href="#">5</a>
                </li>
                <li><a href="#">&raquo;</a>
                </li>
            </ul>
        </div>


    </div>
    <!-- /.col-md-9 -->

</div>
<!-- /.container -->