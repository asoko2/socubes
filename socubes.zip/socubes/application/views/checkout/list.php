<div class="container">

    <div class="col-md-9" id="checkout">

        <div class="box">
            <?php echo form_open('checkout/detail') ?>
                <h1>Checkout</h1>
                <ul class="nav nav-pills nav-justified">
                    <li class="active"><a href="#"><i class="fa fa-map-marker"></i><br>Alamat</a>
                    </li>
                    <li class="disabled"><a href="#"><i class="fa fa-eye"></i><br>Ringkasan Order</a>
                    </li>
                </ul>
                <div class="content">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php
                                if($this->session->flashdata('error')){
                                    echo '<div class="alert alert-warning">';
                                    echo $this->session->flashdata('error');
                                    echo '</div>';
                                }

                                echo validation_errors('<div class="alert alert-warning">','</div>');
                            ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="firstname">Nama Penerima</label>
                                <input type="text" name="nama_penerima" class="form-control" id="firstname" value="<?php echo $user->nama_depan.' '.$user->nama_belakang ?>" readonly>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="company">Alamat</label>
                                <textarea name="alamat" class="form-control" required placeholder="Masukkan "><?php echo set_value('alamat') ?></textarea>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Provinsi</label>
                                <select name="provinsi" class="form-control" id="provinsi" required>
                                    <option value=''>Silahkan Pilih</option>
                                    <?php
                                        foreach ($provinsi as $prov) {
                                        echo "<option value='$prov[id]'>$prov[name]</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Kabupaten</label>
                                <select name="kabupaten" class="form-control" id="kabupaten-kota" required>
                                    <option value=''>Silahkan Pilih</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="state">Kecamatan</label>
                                <select name="kecamatan" class="form-control" id="kecamatan" required>
                                    <option value=''>Silahkan Pilih</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="state">Kelurahan</label>
                                <select name="kelurahan" class="form-control" id="kelurahan-desa" required>
                                    <option value=''>Silahkan Pilih</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Telepon</label>
                                <input type="text" name="telepon" onkeypress="return hanyaAngka(event)" class="form-control" value="<?php echo set_value('telepon') ?>" required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="box-footer">
                    <div class="pull-left">
                        <a href="<?php echo base_url('cart') ?>" class="btn btn-default"><i class="fa fa-chevron-left"></i>Kembali ke keranjang</a>
                    </div>
                    <div class="pull-right">
                        <button type="submit" class="btn btn-primary">Lanjut ke Ringkasan Order<i class="fa fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.box -->


    </div>
    <!-- /.col-md-9 -->

</div>
<!-- /.container -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-2.1.3.min.js"></script>

<script type="text/javascript">

$(function(){

    $.ajaxSetup({
        type:"POST",
        url: "<?php echo base_url('checkout/ambil_data') ?>",
        cache: false,
    });

    $("#provinsi").change(function(){

        var value=$(this).val();
        if(value>0){
        $.ajax({
            data:{modul:'kabupaten',id:value},
            success: function(respond){
              $("#kabupaten-kota").html(respond);
            }
        });
        }

    });


    $("#kabupaten-kota").change(function(){
        var value=$(this).val();
        if(value>0){
            $.ajax({
                data:{modul:'kecamatan',id:value},
                success: function(respond){
                    $("#kecamatan").html(respond);
                }
            });
        }
    });

    $("#kecamatan").change(function(){
        var value=$(this).val();
        if(value>0){
            $.ajax({
                data:{modul:'kelurahan',id:value},
                success: function(respond){
                    $("#kelurahan-desa").html(respond);
                }
            });
        }
    });

});

function hanyaAngka(evt) {
          var charCode = (evt.which) ? evt.which : event.keyCode
           if (charCode > 31 && (charCode < 48 || charCode > 57))
 
            return false;
          return true;
        }

</script>