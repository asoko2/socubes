<a href="#" data-toggle="modal" data-target="#login-modal1" class="btn btn-primary">Checkout<i class="fa fa-chevron-right"></i></a>
<div class="modal fade" id="login-modal1" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
    <div class="modal-dialog modal-sm">

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="Login">Proses checkout?</h4>
            </div>
            <div class="modal-body">
                <?php echo form_open('checkout/checkout') ?>
                <p class="text-center">
                <input type="hidden" name="id_transaksi" value="<?php $id = $this->session->userdata('id_transaksi'); 
                if($this->session->userdata('id_transaksi')==''){
                    echo $id['id_transaksi'];
                    }else{
                        echo $id;
                        } ?>">
                    <?php 
                        date_default_timezone_set('Asia/Jakarta');
                        $tanggal = date('Y-m-d');
                    ?>
                    <input type="hidden" name="penerima" value="<?php echo $nama ?>">
                    <input type="hidden" name="tanggal" value="<?php echo $tanggal ?>">
                    <input type="hidden" name="alamat" value="<?php echo $alamat.' '.$kelurahan.', '.$kecamatan.', '.$kabupaten.', '.$provinsi?>">
                    <input type="hidden" name="telepon" value="<?php echo $telepon ?>">
                    <input type="hidden" name="total"   value="<?php echo $count ?>">
                <button type="submit" class="btn btn-primary">Ya</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Tidak</button>
                </p>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>
