<div class="container">

    <div class="col-md-9" id="checkout">

        <div class="box">

            <h1>Checkout - Order review</h1>
            <ul class="nav nav-pills nav-justified">
                <li><a href="<?php echo base_url('checkout') ?>"><i class="fa fa-map-marker"></i><br>Alamat</a>
                </li>
                <li class="active"><a href="#"><i class="fa fa-eye"></i><br>Ringkasan Order</a>
                </li>
            </ul>

            <div class="content">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th colspan="2">Produk</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($cart as $cart) { 
                                    $rubik = $this->rubik_model->detail($cart->id_produk); ?>
                            <tr>
                                <td>
                                    <a href="#">
                                        <img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" alt="White Blouse Armani">
                                    </a>
                                </td>
                                <td><a href="#"><?php echo $rubik->nama_produk ?></a>
                                </td>
                                <td><?php echo $cart->jumlah ?></td>
                                <td>Rp <?php echo $rubik->harga ?></td>
                                <td>Rp <?php echo $cart->subtotal ?></td>
                            </tr>
                        </tbody>
                            <?php } ?>
                        <tfoot>
                            <tr>
                                <th colspan="4">Total</th>
                                <th>Rp <?php echo $count ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <!-- /.table-responsive -->
                <div class="table-responsive">
                    <table class="table">
                        <tr>
                            <td>Nama Penerima</td>
                            <td>:</td>
                            <td><?php echo $this->input->post('nama_penerima') ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo $alamat.' '.$kelurahan.', '.$kecamatan.', '.$kabupaten.', '.$provinsi ?></td>
                        </tr>
                        <tr>
                            <td>Telepon</td>
                            <td>:</td>
                            <td><?php echo $telepon ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <!-- /.content -->

            <div class="box-footer">
                <div class="pull-left">
                    <a href="<?php echo base_url('checkout') ?>" class="btn btn-default"><i class="fa fa-chevron-left"></i>Kembali ke alamat</a>
                </div>
                <div class="pull-right">
                    
                    <?php include('check.php'); ?>
                    
                    </button>
                </div>
            </div>
        </div>
        <!-- /.box -->


    </div>
    <!-- /.col-md-9 -->

</div>
<!-- /.container -->