<div class="container">

    <div class="col-md-6 col-md-offset-3">
        <div class="box">
            <h1>Checkout selesai</h1>

            <p class="lead">Silahkan lakukan transfer sesuai dengan total pembelian anda ke rekening berikut : </p>
            <table class="table">
            	<tr>
            		<td>BRI</td>
            		<td>:</td>
            		<td>1234-5678-9010-1112</td>
            	</tr>
            	<tr>
            		<td>MANDIRI</td>
            		<td>:</td>
            		<td>1234-5678-9010-1112</td>
            	</tr>
            </table>
            <p class="lead">Jika sudah silahkan lakukan konfirmasi pembayaran di menu Order atau klik <a href="<?php echo base_url('order') ?>">di sini</a></p>
        </div>
    </div>

</div>
<!-- /.container -->