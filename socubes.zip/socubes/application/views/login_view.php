<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Obaju e-commerce template">
    <meta name="author" content="Ondrej Svestka | ondrejsvestka.cz">
    <meta name="keywords" content="">

    <title>
        <?php echo $title; ?>
    </title>

    <meta name="keywords" content="">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

    <!-- styles -->
    <link href="<?php echo base_url() ?>/assets/obaju/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/obaju/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/obaju/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/obaju/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/obaju/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/obaju/css/owl.theme.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/obaju/css/custom.css" rel="stylesheet">

    <!-- theme stylesheet -->
    <link href="<?php echo base_url() ?>/assets/obaju/css/style.default.css" rel="stylesheet" id="theme-stylesheet">

    <!-- your stylesheet with modifications -->

    <script src="<?php echo base_url() ?>/assets/obaju/js/respond.min.js"></script>

    <link rel="shortcut icon" href="favicon.png">

</head>

<body><!-- *** TOPBAR ***
 _________________________________________________________ -->
    <div id="top">
        <div class="container">
            <div class="col-md-6 col-md-offset-6" data-animate="fadeInDown">
                <ul class="menu">
                    <li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                            </li>
                            <li><a href="<?php echo base_url() ?>daftar">Daftar</a>
                            </li>                    
                            <li><a href="<?php echo base_url() ?>kontak">Kontak</a>
                    </li>
                                        
                </ul>
            </div>
        </div>
        <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
            <div class="modal-dialog modal-sm">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="Login">Login</h4>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo base_url() ?>login" method="post" accept-charset="utf-8">
                            <div class="form-group">
                                <input type="text" name="username" class="form-control" id="email-modal" placeholder="username">
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" id="password-modal" placeholder="password">
                            </div>

                            <p class="text-center">
                                <button class="btn btn-primary"><i class="fa fa-sign-in"></i>Masuk</button>
                            </p>

                        </form>
                        <p class="text-center text-muted">Belum terdaftar ?</p>
                        <p class="text-center text-muted"><a href="<?php echo base_url() ?>daftar"><strong>Daftar sekarang</strong></a></p>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- *** TOP BAR END *** -->
<!-- *** NAVBAR ***
 _________________________________________________________ -->

    <div class="navbar navbar-default yamm" role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand home" href="<?php echo base_url() ?>" data-animate-hover="bounce">
                    <h3>SoCubes</h3>
                    <!--<img src="<?php echo base_url() ?>/assets/obaju/img/logo.png" alt="Obaju logo" class="hidden-xs">
                    <img src="<?php echo base_url() ?>/assets/obaju/img/logo-small.png" alt="Obaju logo" class="visible-xs"><span class="sr-only">Obaju - go to homepage</span>-->
                </a>
                <div class="navbar-buttons">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-align-justify"></i>
                    </button>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search">
                        <span class="sr-only">Toggle search</span>
                        <i class="fa fa-search"></i>
                    </button>
                    <a class="btn btn-default navbar-toggle" href="<?php echo base_url() ?>/assets/obaju/basket.html">
                        <i class="fa fa-shopping-cart"></i>  <span class="hidden-xs">3 items in cart</span>
                    </a>
                </div>
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse" id="navigation">

                <ul class="nav navbar-nav navbar-left">
                    <li class="">
                        <a href="<?php echo base_url() ?>">Home</a>
                    </li>
                    <li class="dropdown yamm-fw">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Kategori <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <ul>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/2x2">2x2</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/3x3">3x3</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/4x4">4x4</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/5x5">5x5</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/6x6">6x6</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/7x7">7x7</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/megaminx">Megaminx</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/pyraminx">Pyraminx</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/rubiks-clock">Rubik's Clock</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/skewb">Skewb</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/kategori/square-1">Square-1</a>
                                                </li>
                                            </ul>
                                        </div>                                        
                                    </div>
                                </div>
                                <!-- /.yamm-content -->
                            </li>
                        </ul>
                    </li>

                    <li class="dropdown yamm-fw">
                        <a href="<?php echo base_url() ?>#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Brand <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <ul>
                                                <li><a href="<?php echo base_url() ?>produk/brand/moyu">Moyu</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/brand/qiyi">Qiyi</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/brand/dayan">Dayan</a>
                                                </li>
                                                <li><a href="<?php echo base_url() ?>produk/brand/gan">GAN</a>
                                                </li>
                                            </ul>
                                        </div>                                        
                                    </div>
                                </div>
                                <!-- /.yamm-content -->
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!--/.nav-collapse -->

            <div class="navbar-buttons">
                <!--/.nav-collapse -->

                <div class="navbar-collapse collapse right" id="search-not-mobile">
                    <button type="button" class="btn navbar-btn btn-primary" data-toggle="collapse" data-target="#search">
                        <span class="sr-only">Toggle search</span>
                        <i class="fa fa-search"></i>
                    </button>
                </div>

            </div>

            <div class="collapse clearfix" id="search">

                <form class="navbar-form" role="search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-btn">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            		    </span>
                    </div>
                </form>

            </div>
            <!--/.nav-collapse -->

        </div>
        <!-- /.container -->
    </div>
    <!-- /#navbar -->

    <!-- *** NAVBAR END *** -->
    <div id="all">

        <div id="content"><div class="container">

    <div class="col-md-6 col-md-offset-3">
    <div class="box">
        <h1>Login</h1>
        <p class="text-muted">Masukkan username & password</p>

        <hr>
        <?php 
            // Validasi form
            echo validation_errors('<div class="alert alert-warning">','</div>');

            // Cetak notifikasi
            if($this->session->flashdata('sukses')){
                echo '<div class="alert alert-success">';
                echo $this->session->flashdata('sukses');
                echo '</div>';
        }
        ?>
        <?php echo form_open(base_url('login')); ?>
            <div class="form-group">
                <label for="email">Username</label>
                <input type="text" name="username" class="form-control" id="email" value="<?php echo set_value('username') ?>">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password">
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary"><i class="fa fa-sign-in"></i> Log in</button>
            </div>
        <?php echo form_close() ?>
    </div>
</div>

</div>
<!-- /.container -->        </div>
<!-- *** FOOTER ***
 _________________________________________________________ -->
        <div id="footer" data-animate="fadeInUp">
            <div class="container">
                <div class="row">
                      <div class="col-md-3 col-sm-6">
                                    <h4>User section</h4>
                                    <ul>
                                        <li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                                        </li>
                                        <li><a href="<?php echo base_url('daftar') ?>">Register</a>
                                        </li>
                                    </ul>

                                    <hr class="hidden-md hidden-lg hidden-sm">
                                </div>                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4>About</h4>
                        <p>
                            SoCubes merupakan toko rubik terpercaya di Indonesia.
                        </p>

                    </div>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4>Kantor Kami</h4>

                        <p><strong>SoCubes</strong>
                            <br>Jalan Tri Tunggal No. 45
                            <br>Karangpacar
                            <br>Bojonegoro
                            <br>Jawa Timur
                            <br>
                            <strong>Indonesia</strong>
                        </p>

                        <a href="contact.html">KONTAK</a>

                        <hr class="hidden-md hidden-lg">

                    </div>
                    <!-- /.col-md-3 -->



                    <div class="col-md-3 col-sm-6">
                        <h4>Hubungi Kami Melalui</h4>

                        <p class="social">
                            <a href="http://www.facebook.com/asoko2" class="facebook external" data-animate-hover="shake"><i class="fa fa-facebook"></i></a>
                            <a href="http://www.twitter.com/ananghar1" class="twitter external" data-animate-hover="shake"><i class="fa fa-twitter"></i></a>
                            <a href="http://www.instagram.com/instagram" class="instagram external" data-animate-hover="shake"><i class="fa fa-instagram"></i></a>
                        </p>


                    </div>
                    <!-- /.col-md-3 -->

                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </div>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">&copy; 2017 SoCubes.</p>

                </div>
                <div class="col-md-6">
                    <p class="pull-right">Template by <a href="https://bootstrapious.com/e-commerce-templates">Bootstrapious.com</a>
                         <!-- Not removing these links is part of the license conditions of the template. Thanks for understanding :) If you want to use the template without the attribution links, you can do so after supporting further themes development at https://bootstrapious.com/donate  -->
                    </p>
                </div>
            </div>
        </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->


    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="<?php echo base_url() ?>assets/obaju/js/jquery-1.11.0.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/jquery.cookie.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/waypoints.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/modernizr.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/bootstrap-hover-dropdown.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/front.js"></script>


</body>

</html>