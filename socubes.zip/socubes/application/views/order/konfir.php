<div class="container">

    <div class="col-md-6 col-md-offset-3">
        <div class="box">
            <h1>Konfirmasi Pembayaran</h1>
            <?php echo form_open('order/konfirmasi') ?>
            <div class="form-group">
                <label>ID Transaksi</label>
                <input type="text" name="id_transaksi" class="form-control" value="<?php echo $this->input->post('id_transaksi') ?>" readonly>   
            </div>
            <div class="form-group">
                <label>No. Rekening</label>
                <input type="text" name="rekening" class="form-control" value="<?php echo set_value('rekening') ?>" required>
            </div>
            <div class="form-group">
                <label>Atas Nama</label>
                <input type="text" name="nama" class="form-control" value="<?php echo set_value('nama') ?>" required>
            </div>
            <div class="form-group">
                <label>Nominal Transfer</label>
                <input type="text" name="nominal" class="form-control" value="<?php echo set_value('nominal') ?>" required>
            </div>
            <div class="form-group">
                <p class="text-center">
                    <button type="submit" class="btn btn-warning">Konfirmasi Pembayaran</button>
                </p>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>

</div>
<!-- /.container -->