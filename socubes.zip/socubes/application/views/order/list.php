<div class="container">

    <div class="col-md-8 col-md-offset-2">
        <div class="box">
            <h1>Riwayat Order Anda <?php //echo $trans->id_transaksi ?></h1>
            <div class="panel-group">
                <?php $i=1; foreach($trans as $trans) {
                    $count = $this->cart_model->jumlah($trans->id_transaksi); ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" href="#collapse<?php echo $i ?>">ID : <?php echo $trans->id_transaksi ?> | Tanggal  :  <?php echo $trans->tanggal ?> | Status : 
                            <?php if($trans->status=='1'){
                                echo 'Belum Dibayar';
                                } else if($trans->status=='2'){
                                    echo 'Menunggu Konfirmasi';
                                } else {
                                    echo 'Sudah Diproses';
                                }
                            ?> </a>
                        </h4>
                    </div>
                    <div id="collapse<?php echo $i ?>" class="panel-collapse collapse">
                        <div class="panel-body">
                            <?php $cart = $this->cart_model->data($trans->id_transaksi); ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Produk</th>
                                            <th>Nama Produk</th>
                                            <th>Jumlah</th>
                                            <th>Harga</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($cart as $cart) { 
                                            $rubik = $this->rubik_model->detail($cart->id_produk); ?>
                                        <tr>
                                            <td><img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" width="50"></td>
                                            <td><?php echo $rubik->nama_produk ?></td>
                                            <td><?php echo $cart->jumlah ?></td>
                                            <td><?php echo $rubik->harga ?></td>
                                            <td><?php echo $cart->subtotal ?></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="4">Total</th>
                                            <th><?php echo $count; ?> </th>
                                        </tr>
                                        <tr>
                                            <td>
                                                <?php if($trans->status=='2' OR $trans->status=='1'){

                                                    echo form_open('order/konfir'); ?>
                                                    <input type="hidden" name="id_transaksi" value="<?php echo $trans->id_transaksi ?>">
                                                    <button type="submit" class="btn btn-warning">Konfirmasi Pembayaran</button>
                                                    <?php echo form_close(); 

                                                } ?>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $i++; } ?>
            </div>
        </div>
    </div>

</div>
<!-- /.container -->