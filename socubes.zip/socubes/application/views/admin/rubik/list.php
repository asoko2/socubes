<?php
// Cetak notifikasi
if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>
<a href="<?php echo base_url('admin/rubik/tambah') ?>" class="btn btn-primary" title="Tambah Rubik"><i class="fa fa-plus"></i>&nbsp;Tambah Rubik</a><br><br>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Gambar</th>
            <th>Nama</th>
            <th>Brand</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Deskripsi</th>
            <th>Slug</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1; foreach($rubik as $rubik){ ?>
        <tr class="odd gradeX">
            <td><?php echo $i ?></td>
            <td><img src="<?php echo base_url('assets/upload/gambar/'.$rubik->gambar) ?>" width="50"></td>
            <td><?php echo $rubik->nama_produk ?></td>
            <td><?php echo $rubik->nama_brand ?></td>
            <td><?php echo $rubik->nama_kategori ?></td>
            <td><?php echo $rubik->harga ?></td>
            <td><?php echo $rubik->stok ?></td>
            <td><?php echo character_limiter($rubik->deskripsi,100) ?></td>
            <td><?php echo $rubik->slug_produk ?></td>
            <td>
                <a href="<?php echo base_url('admin/rubik/edit/'.$rubik->id_produk) ?>" class="btn btn-primary btn-sm" title="Edit rubik"><i class="fa fa-edit"></i></a>
                <?php
                    include('delete.php');
                ?>
            </td>
        </tr>
        <?php $i++; } ?>
    </tbody>
</table>