<?php
	echo validation_errors('<div class="alert alert-warning">','</div>');

	echo form_open_multipart(base_url('admin/rubik/edit/'.$rubik->id_produk));
?>
	<div class="col-md-12">
		<div class="col-md-4">
			<div class="form-group">
				<label>Nama Rubik</label>
				<input type="text" name="nama_produk" class="form-control" placeholder="Nama Rubik" value="<?php echo $rubik->nama_produk ?>">
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>Gambar</label>
				<input type="file" name="gambar" class="form-control">
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>Kategori</label>
				<select class="form-control" name="id_kategori">
					<option>Pilih Kategori</option>
					<?php foreach($kategori as $kategori) { ?>
					<option value="<?php echo $kategori->id_kategori ?>" 
						<?php if($rubik->id_kategori==$kategori->id_kategori){ echo 'selected';}; ?>><?php echo $kategori->nama_kategori ?>
					</option>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>Brand</label>
				<select class="form-control" name="id_brand">
					<option>Pilih Brand</option>
					<?php foreach($brand as $brand) { ?>
					<option value="<?php echo $brand->id_brand ?>"
						<?php if($rubik->id_brand==$brand->id_brand){ echo 'selected';}; ?>><?php echo $brand->nama_brand ?>				
					</option>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>Stok</label>
				<input type="text" name="stok" class="form-control" placeholder="Stok" value="<?php echo $rubik->stok ?>">
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>Harga</label>
				<input type="text" name="harga" class="form-control" placeholder="Harga" value="<?php echo $rubik->harga ?>">
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<label>Deskripsi</label>
				<textarea class="form-control" name="deskripsi"><?php echo $rubik->deskripsi ?></textarea>
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Simpan">
				<a href="<?php echo base_url('admin/rubik') ?>" class="btn btn-default">Batal</a>
			</div>
		</div>
	</div>
<?php
	echo form_close();
?>