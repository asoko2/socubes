<?php
	echo validation_errors('<div class="alert alert-warning">','</div>');

	echo form_open(base_url('admin/user/tambah'));
?>
	<div class="col-md-4 col-md-offset-2">
		<div class="form-group">
			<label>Nama Depan</label>
			<input type="text" name="nama_depan" class="form-control" placeholder="Nama Depan" value="<?php echo set_value('nama_depan') ?>">
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group">
			<label>Nama Belakang</label>
			<input type="text" name="nama_belakang" class="form-control" placeholder="Nama Belakang" value="<?php echo set_value('nama_belakang') ?>">
		</div>
	</div>
	<div class="col-md-4 col-md-offset-2">
		<div class="form-group">
			<label>Username</label>
			<input type="text" name="username" class="form-control" placeholder="Password" value="<?php echo set_value('username') ?>">
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group">
			<label>Email</label>
			<input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo set_value('email') ?>">
			<input type="hidden" name="akses" class="form-control" value="admin">
		</div>
	</div>
	<div class="col-md-4  col-md-offset-2">
		<div class="form-group">
			<label>Password</label>
			<input type="password" name="password" class="form-control" placeholder="Password" value="<?php echo set_value('password') ?>">
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group">
			<label>Ulangi Password</label>
			<input type="password" name="password2" class="form-control" placeholder="Ulangi Password" value="<?php echo set_value('password2') ?>">
		</div>
	</div>
	<div class="col-md-6 col-md-offset-2">
		<input type="submit" name="submit" class="btn btn-primary" value="Simpan">
		<a href="<?php echo base_url('admin/user/admin') ?>" class="btn btn-default">Batal</a>
	</div>
<?php
	echo form_close();
?>