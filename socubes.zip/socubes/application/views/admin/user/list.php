<?php
// Cetak notifikasi
if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama Depan</th>
            <th>Nama Belakang</th>
            <th>Email</th>
            <th>Username</th>
            <th>Akses Level</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1; foreach($user as $user){ ?>
        <tr class="odd gradeX">
            <td><?php echo $i ?></td>
            <td><?php echo $user->nama_depan ?></td>
            <td><?php echo $user->nama_belakang ?></td>
            <td><?php echo $user->email ?></td>
            <td><?php echo $user->username ?></td>
            <td><?php echo $user->akses_level ?></td>
            <td>
                <?php if($user->akses_level == 'user'){
                    include('delete.php');
                }
                ?>
                <?php if($user->username==$this->session->userdata('username')){
                    echo '<a href="'.base_url('admin/user/gantipass/'.$user->id_user).'" class="btn btn-primary btn-sm" title="Ganti Password">Ganti Password</a>';
                }
                ?>
            </td>
        </tr>
        <?php $i++; } ?>
    </tbody>
</table>