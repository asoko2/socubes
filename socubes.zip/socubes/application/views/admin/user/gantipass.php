<?php
	echo validation_errors('<div class="alert alert-warning">','</div>');
	// Cetak notifikasi
    if($this->session->flashdata('error')){
        echo '<div class="alert alert-warning">';
        echo $this->session->flashdata('error');
        echo '</div>';
    }

	echo form_open(base_url('admin/user/gantipass/'.$user->id_user));
?>
	<div class="col-md-6">
		<?php
			if($this->input->post('password')){
	    	echo sha1($this->input->post('password'));
	    }
	    ?>
		<div class="form-group">
			<label>Password Lama <?php echo $user->password ?></label>
			<input type="text" name="password_lama" class="form-control" placeholder="Password Lama" value="<?php echo set_value('password_lama') ?>">
		</div>
		<div class="form-group">
			<label>Password Baru</label>
			<input type="text" name="password_baru" class="form-control" placeholder="Password Baru" value="<?php echo set_value('password_baru') ?>">
		</div>
		<div class="form-group">
			<label>Konfirmasi Password</label>
			<input type="text" name="konfir_pass" class="form-control" placeholder="Konfirmasi Password" value="<?php echo set_value('konfir_pass') ?>">
		</div>
		<input type="submit" name="submit" class="btn btn-primary" value="Simpan">
		<a href="<?php echo base_url('admin/kategori') ?>" class="btn btn-default">Batal</a>
	</div>
	<div class="col-md-6">
		<div class="form-group">
			<?php echo form_error('password_lama','<div class="alert alert-warning">','</div>'); ?>
		</div>
	</div>
<?php
	echo form_close();
?>