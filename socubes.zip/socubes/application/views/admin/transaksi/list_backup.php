<?php
// Cetak notifikasi
if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Tanggal</th>
            <th>Pembeli</th>
            <th>Alamat</th>
            <th>Total</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1; foreach($transaksi as $trans){ ?>
        <tr class="odd gradeX">
            <td><?php echo $i ?></td>
            <td><?php echo $trans->tanggal; ?></td>
            <td><?php echo $trans->id_user; ?></td>
            <td><?php echo $trans->alamat; ?></td>
            <td><?php echo $trans->total; ?></td>
            <td>
                <a href="" class="btn btn-primary btn-sm" title="Edit kategori">Konfir Pembayaran</i></a>
            </td>
        </tr>
        <?php $i++; } ?>
    </tbody>
</table>