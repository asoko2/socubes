<?php
// Cetak notifikasi
if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>Detail Transaksi</th>
        </tr>
    </thead>
    <tbody>
                    <?php $i=1; foreach($transaksi as $trans) {
                        $count = $this->cart_model->jumlah($trans->id_transaksi); ?>
        <tr class="odd gradeX">
            <td>
                <div class="panel-group">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" href="#collapse<?php echo $i ?>">
                                <table>
                                    <tr>
                                <td>ID : <?php echo $trans->id_transaksi ?></td>
                                <td>&nbsp;|&nbsp;</td>
                                <td>Tanggal  :  <?php echo $trans->tanggal ?></td>
                                <td>&nbsp;|&nbsp;</td>
                                <td>Status : 
                                <?php if($trans->status=='1'){
                                    echo 'Belum Dibayar';
                                    } else if($trans->status=='2'){
                                        echo 'Menunggu Konfirmasi';
                                    } else {
                                        echo 'Sudah Diproses';
                                    }
                                ?></td>
                                    </tr>
                                </table>
                                </a>
                            </h4>
                        </div>
                        <div id="collapse<?php echo $i ?>" class="panel-collapse collapse">
                            <div class="panel-body">
                                <?php $cart = $this->cart_model->data($trans->id_transaksi); ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Produk</th>
                                                <th>Nama Produk</th>
                                                <th>Jumlah</th>
                                                <th>Harga</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($cart as $cart) { 
                                                $rubik = $this->rubik_model->detail($cart->id_produk); ?>
                                            <tr>
                                                <td><img src="<?php echo base_url('assets/upload/gambar/thumbs/'.$rubik->gambar) ?>" width="50"></td>
                                                <td><?php echo $rubik->nama_produk ?></td>
                                                <td><?php echo $cart->jumlah ?></td>
                                                <td><?php echo $rubik->harga ?></td>
                                                <td><?php echo $cart->subtotal ?></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="5">Total</th>
                                                <th><?php echo $count; ?> </th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <div class="table-responsive">
                                        <?php $nama = $this->user_model->detail($trans->id_user) ?>
                                        <table class="table">
                                            <tr>
                                                <td>Nama Penerima</td>
                                                <td>:</td>
                                                <td><?php echo $trans->penerima ?></td>
                                            </tr>
                                            <tr>
                                                <td>Alamat</td>
                                                <td>:</td>
                                                <td><?php echo $trans->alamat ?></td>
                                            </tr>
                                            <tr>
                                                <td>Telepon</td>
                                                <td>:</td>
                                                <td><?php echo $trans->telp ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <?php //include('konfir.php'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>
                    <?php $i++; } ?>
    </tbody>
</table>