<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal<?php echo $bayar->id_transaksi; ?>" title="Konfirmasi Pembayaran">
    Konfirmasi Pembayaran
</button>
<div class="modal fade" id="myModal<?php echo $bayar->id_transaksi; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Konfirmasi Pembayaran?</h4>
            </div>
            <!--<div class="modal-body">
                Konfirmasi Pembayaran?
            </div>-->
            <div class="modal-footer">
                <?php echo form_open('admin/transaksi/konfir'); ?>
                    <input type="hidden" name="id_transaksi" value="<?php echo $bayar->id_transaksi ?>">
                    <button type="submit" class="btn btn-primary">Ya</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tidak</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>