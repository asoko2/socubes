<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>ID Transaksi</th>
            <th>NO. Rekening</th>
            <th>Atas Nama</th>
            <th>Nominal</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1; foreach($bayar as $bayar){ ?>
        <tr class="odd gradeX">
            <td><?php echo $i ?></td>
            <td><?php echo $bayar->id_transaksi ?></td>
            <td><?php echo $bayar->no_rekening ?></td>
            <td><?php echo $bayar->nama_rekening ?></td>
            <td><?php echo $bayar->nominal?></td>
            <td>
                <?php
                    if($bayar->status=='1' OR $bayar->status=='2'){
                        include('konfir.php');
                    } else if($bayar->status=='3'){
                        echo 'Sudah Dikonfirmasi';
                    }
                ?>
            </td>
        </tr>
        <?php $i++; } ?>
    </tbody>
</table>