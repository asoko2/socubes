	<div class="jumbotron">
	  <h1>&nbsp;Selamat Datang Admin SoCubes</h1>
	  <p>&nbsp;&nbsp;&nbsp;Silahkan melakukan pengolahan data</p>
	</div>