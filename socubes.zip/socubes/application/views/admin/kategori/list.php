<?php
// Cetak notifikasi
if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>
<a href="<?php echo base_url('admin/kategori/tambah') ?>" class="btn btn-primary" title="Tambah Kategori"><i class="fa fa-plus"></i>&nbsp;Tambah Kategori</a><br><br>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Kategori</th>
            <th>Keterangan</th>
            <th>Slug</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1; foreach($kategori as $kategori){ ?>
        <tr class="odd gradeX">
            <td><?php echo $i ?></td>
            <td><?php echo $kategori->nama_kategori ?></td>
            <td><?php echo $kategori->keterangan ?></td>
            <td><?php echo $kategori->slug_kategori ?></td>
            <td>
                <a href="<?php echo base_url('admin/kategori/edit/'.$kategori->id_kategori) ?>" class="btn btn-primary btn-sm" title="Edit kategori"><i class="fa fa-edit"></i></a>
                <?php
                    include('delete.php');
                ?>
            </td>
        </tr>
        <?php $i++; } ?>
    </tbody>
</table>