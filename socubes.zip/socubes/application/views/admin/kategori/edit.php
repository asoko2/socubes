<?php
	echo validation_errors('<div class="alert alert-warning">','</div>');

	echo form_open(base_url('admin/kategori/edit/'.$kategori->id_kategori));
?>
	<div class="col-md-6">
		<div class="form-group">
			<label>Nama Kategori</label>
			<input type="text" name="nama_kategori" class="form-control" placeholder="Nama Kategori" value="<?php echo $kategori->nama_kategori ?>" readonly>
		</div>
		<div class="form-group">
			<label>Keterangan</label>
			<textarea name="keterangan" class="form-control" placeholder="keterangan"><?php echo $kategori->keterangan ?></textarea>
		</div>
		<input type="submit" name="submit" class="btn btn-primary" value="Simpan">
		<a href="<?php echo base_url('admin/kategori') ?>" class="btn btn-default">Batal</a>
	</div>
<?php
	echo form_close();
?>