           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a  href="<?php echo base_url('admin/kategori') ?>"><i class="glyphicon glyphicon-th-list"></i>Kategori</a>
                    </li>
                    <li>
                        <a  href="<?php echo base_url('admin/brand') ?>"><i class="fa fa-tag"></i>Brand</a>
                    </li>
                    <li>
                        <a  href="<?php echo base_url('admin/rubik') ?>"><i class="fa fa-cubes"></i>Rubik</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-users"></i>User<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?php echo base_url('admin/user/admin') ?>"><i class="fa fa-user-secret"></i>Admin</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('admin/user/user') ?>"><i class="fa fa-user"></i>User</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('admin/user/tambah') ?>"><i class="fa fa-user-plus"></i>Tambah Admin</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-users"></i>Pesanan<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?php echo base_url('admin/transaksi') ?>"><i class="fa fa-cart-arrow-down"></i>Transaksi</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('admin/transaksi/pembayaran') ?>"><i class="fa fa-money"></i>Pembayaran</a>
                            </li>
                        </ul>
                    </li>
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h3><?php echo $title; ?></h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <!-- Form Elements -->
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="table-responsive">