<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal<?php echo $brand->id_brand; ?>" title="Hapus data brand">
    <i class="fa fa-trash"></i>
</button>
<div class="modal fade" id="myModal<?php echo $brand->id_brand; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Hapus Data Brand</h4>
            </div>
            <div class="modal-body">
                Yakin ingin menghapus data brand ini?
            </div>
            <div class="modal-footer">
                <a href="<?php echo base_url('admin/brand/hapus/'.$brand->id_brand); ?>" class="btn btn-primary">Ya</a>
                <button type="button" class="btn btn-default" data-dismiss="modal">Tidak</button>
            </div>
        </div>
    </div>
</div>