<?php
// Cetak notifikasi
if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>
<a href="<?php echo base_url('admin/brand/tambah') ?>" class="btn btn-primary" title="Tambah Brand"><i class="fa fa-plus"></i>&nbsp;Tambah Brand</a><br><br>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>#</th>
            <th>Brand</th>
            <th>Slug</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1; foreach($brand as $brand){ ?>
        <tr class="odd gradeX">
            <td><?php echo $i ?></td>
            <td><?php echo $brand->nama_brand ?></td>
            <td><?php echo $brand->slug_brand ?></td>
            <td>
                <a href="<?php echo base_url('admin/brand/edit/'.$brand->id_brand) ?>" class="btn btn-primary btn-sm" title="Edit brand"><i class="fa fa-edit"></i></a>
                <?php
                    include('delete.php');
                ?>
            </td>
        </tr>
        <?php $i++; } ?>
    </tbody>
</table>