<?php
	echo validation_errors('<div class="alert alert-warning">','</div>');

	echo form_open(base_url('admin/brand/edit/'.$brand->id_brand));
?>
	<div class="col-md-6">
		<div class="form-group">
			<label>Nama Brand</label>
			<input type="text" name="nama_brand" class="form-control" placeholder="Nama Brand" value="<?php echo $brand->nama_brand ?>" >
		</div>
		<input type="submit" name="submit" class="btn btn-primary" value="Simpan">
		<a href="<?php echo base_url('admin/brand') ?>" class="btn btn-default">Batal</a>
	</div>
<?php
	echo form_close();
?>