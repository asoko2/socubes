<!-- *** TOPBAR ***
 _________________________________________________________ -->
    <div id="top">
        <div class="container">
            <div class="col-md-6 col-md-offset-6" data-animate="fadeInDown">
                <ul class="menu">
                    <?php
                    if($this->session->userdata('username') ==''){
                        echo '<li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                            </li>
                            <li><a href="'.base_url('daftar').'">Daftar</a>
                            </li>';
                    }else{
                        echo '<li><a href="'.base_url('profil/').'"><i class="fa fa-user"></i>'.$this->session->userdata('nama_depan').'</a></li>';
                    }
                    ?>
                    <?php if($this->session->userdata('username') ==''){

                    }else{
                        echo '<li><a href="'.base_url('order').'">Order</a>';
                    }
                    ?>
                    <li><a href="<?php echo base_url('kontak') ?>">Kontak</a>
                    </li>
                    <?php 
                    if($this->session->userdata('username') !=''){
                        echo ' <li><a href="'.base_url('login/logout').'"><i class="fa fa-sign-out"></i>Logout</a></li>';
                    }
                    ?>
                    
                </ul>
            </div>
        </div>
        <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
            <div class="modal-dialog modal-sm">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="Login">Login</h4>
                    </div>
                    <div class="modal-body">
                        <?php echo form_open('login') ?>
                            <div class="form-group">
                                <input type="text" name="username" class="form-control" id="email-modal" placeholder="username">
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" id="password-modal" placeholder="password">
                            </div>

                            <p class="text-center">
                                <button class="btn btn-primary"><i class="fa fa-sign-in"></i>Masuk</button>
                            </p>

                        <?php echo form_close() ?>

                        <p class="text-center text-muted">Belum terdaftar ?</p>
                        <p class="text-center text-muted"><a href="<?php echo base_url('daftar') ?>"><strong>Daftar sekarang</strong></a></p>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- *** TOP BAR END *** -->
