<?php

include_once('head.php');
include_once('header.php');
include_once('nav.php');
if(isset($sidebar)) {
	include_once('sidebar.php');
}
include_once('content.php');
include_once('footer.php');
?>