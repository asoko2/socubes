<?php
if($sidebar){
	$this->load->view($sidebar);
}