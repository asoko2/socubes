        </div>
<!-- *** FOOTER ***
 _________________________________________________________ -->
        <div id="footer" data-animate="fadeInUp">
            <div class="container">
                <div class="row">
                    <?php if($this->session->userdata('username')==''){
                        echo '  <div class="col-md-3 col-sm-6">
                                    <h4>User section</h4>
                                    <ul>
                                        <li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                                        </li>
                                        <li><a href="'.base_url('daftar').'">Regiter</a>
                                        </li>
                                    </ul>

                                    <hr class="hidden-md hidden-lg hidden-sm">
                                </div>';
                    }else{

                    }
                    ?>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4>About</h4>
                        <p>
                            SoCubes merupakan toko rubik terpercaya di Indonesia.

                        </p>

                    </div>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4>Kantor Kami</h4>

                        <p><strong>SoCubes</strong>
                            <br>Jalan Tri Tunggal No. 45
                            <br>Karangpacar
                            <br>Bojonegoro
                            <br>Jawa Timur
                            <br>
                            <strong>Indonesia</strong>
                        </p>

                        <a href="<?php echo base_url('kontak') ?>">KONTAK</a>

                        <hr class="hidden-md hidden-lg">

                    </div>
                    <!-- /.col-md-3 -->



                    <div class="col-md-3 col-sm-6">
                        <h4>Hubungi Kami Melalui</h4>

                        <p class="social">
                            <a href="http://www.facebook.com/asoko2" class="external facebook" data-animate-hover="pulse"><i class="fa fa-facebook"></i></a>
                            <a href="http://www.twitter.com/ananghar1" class="twitter external" data-animate-hover="pulse"><i class="fa fa-twitter"></i></a>
                            <a href="http://www.instagram.com/instagram" class="instagram external" data-animate-hover="pulse"><i class="fa fa-instagram"></i></a>
                        </p>


                    </div>
                    <!-- /.col-md-3 -->

                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </div>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">&copy; 2017 SoCubes.</p>

                </div>
                <div class="col-md-6">
                    <p class="pull-right">Template by <a href="https://bootstrapious.com/e-commerce-templates">Bootstrapious.com</a>
                         <!-- Not removing these links is part of the license conditions of the template. Thanks for understanding :) If you want to use the template without the attribution links, you can do so after supporting further themes development at https://bootstrapious.com/donate  -->
                    </p>
                </div>
            </div>
        </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->


    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="<?php echo base_url() ?>assets/obaju/js/jquery-1.11.0.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/jquery.cookie.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/waypoints.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/modernizr.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/bootstrap-hover-dropdown.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url() ?>assets/obaju/js/front.js"></script>


</body>

</html>