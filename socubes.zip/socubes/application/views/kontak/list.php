<div class="container">

    <div class="col-md-8 col-md-offset-2">


        <div class="box" id="contact">
            <h1>Kontak</h1>

            <p class="lead">Anda mempunyai pertanyaan? Keluhan? Ataupun kritik dan saran?</p>
            <p>Silahkan hubungi kami melalui kontak di bawah ini, kami akan memberi respon secepatnya.</p>

            <hr>

            <div class="row">
                <div class="col-sm-4">
                    <h3><i class="fa fa-map-marker"></i> Kantor Kami</h3>
                    <p>Jalan Tri Tunggal No. 45
                        <br>Karangpacar
                        <br>Bojonegoro
                        <br>Jawa Timur
                        <br>
                        <strong>Indonesia</strong>
                    </p>
                </div>
                <!-- /.col-sm-4 -->
                <div class="col-sm-4">
                    <h3><i class="fa fa-phone"></i> SMS/WA</h3>
                    <p><strong>+62 857 3356 6741</strong>
                    </p>
                </div>
                <!-- /.col-sm-4 -->
                <div class="col-sm-4">
                    <h3><i class="fa fa-envelope"></i> Email</h3>
                    <strong><a href="mailto:">sokoanang@gmail.com</a></strong>
                </div>
                <!-- /.col-sm-4 -->
            </div>
            <!-- /.row -->

            <hr>            

        </div>


    </div>
    <!-- /.col-md-9 -->
</div>
<!-- /.container -->