<?php if (!defined('BASEPATH')) exit('No directs script access allowed');

class Transaksi extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$transaksi = $this->cart_model->daftar();

		$data	=	array(	'title'		=>	'Transaksi',
							'transaksi'	=>	$transaksi,
							'isi'		=>	'admin/transaksi/list');
		$this->load->view('admin/layout/wrapper',$data);
	}

	public function konfir(){
		$data 	=	array(	'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'status'		=>	'3');

		$this->cart_model->bayar($data);
		redirect(base_url('admin/transaksi'));

	}

	public function pembayaran(){

		$bayar	=	$this->cart_model->list_bayar();
		
		$data 	=	array(	'title'		=>	'Pembayaran',
							'bayar'		=>	$bayar,
							'isi'		=>	'admin/transaksi/pembayaran');
		
		$this->load->view('admin/layout/wrapper',$data);
		
	}

}