<?php

class Kategori extends CI_Controller {
	
	public function __construct(){

		parent::__construct();
		$this->load->model('kategori_model');

	}

	public function index(){
		$kategori = $this->kategori_model->listing();

		$data = array(	'title'		=> 'Data Kategori',
						'isi'		=> 'admin/kategori/list',
						'kategori'	=> $kategori);
		$this->load->view('admin/layout/wrapper',$data);

	}

	//Tambah Data
	public function tambah(){
		$this->form_validation->set_rules('nama_kategori','Nama Kategori','required|is_unique[kategori.nama_kategori]',
								array(		'required'	=> 'Nama kategori harus diisi',
											'is_unique'	=> 'Nama kategori sudah ada. Silahkan gunakan nama kategori lain.'));
		if($this->form_validation->run()===FALSE){
			$data = array(	'title'	=>	'Tambah Kategori',
							'isi'	=>	'admin/kategori/tambah');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$slug_kategori = url_title($this->input->post('nama_kategori'),'dash',TRUE);
			$data = array(	'nama_kategori'	=> $this->input->post('nama_kategori'),
							'keterangan'	=> $this->input->post('keterangan'),
							'slug_kategori'	=> $slug_kategori);
			$this->kategori_model->tambah($data);
			$this->session->set_flashdata('sukses','Data kategori berhasil ditambah');
			redirect(base_url('admin/kategori'));
		}
	}

	//Edit Data
	public function edit($id_kategori){
		$kategori = $this->kategori_model->detail($id_kategori);
		$this->form_validation->set_rules('nama_kategori','Nama Kategori','required',
								array(		'required'	=> 'Nama kategori harus diisi'));
		
		if($this->form_validation->run()===FALSE){
			$data = array(	'title'		=>	'Edit Kategori',
							'kategori'	=>	$kategori,
							'isi'		=>	'admin/kategori/edit');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$slug_kategori = url_title($this->input->post('nama_kategori'),'dash',TRUE);
			$data = array(	'id_kategori'	=> $id_kategori,
							'nama_kategori'	=> $this->input->post('nama_kategori'),
							'keterangan'	=> $this->input->post('keterangan'),
							'slug_kategori'	=> $slug_kategori);
			$this->kategori_model->edit($data);
			$this->session->set_flashdata('sukses','Data kategori berhasil diedit');
			redirect(base_url('admin/kategori'));
		}
	}

	//Delete data
	public function hapus($id_kategori){
		$data = array('id_kategori'=>$id_kategori);
		$this->kategori_model->delete($data);
		$this->session->set_flashdata('sukses','Data kategori berhasil dihapus');
		redirect('admin/kategori');
	}
}