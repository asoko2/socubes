<?php if (!defined('BASEPATH')) exit('No directs script access allowed');

class Dasbor extends CI_Controller {

	function __construct(){
		parent::__construct();
	}

	function index(){
		$data = array (	'title'		=>	'Halaman Dasbor',
						'isi'		=>	'admin/dasbor/list');
		$this->load->view('admin/layout/wrapper',$data);
	}
}