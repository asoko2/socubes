<?php

class Brand extends CI_Controller {
	
	public function __construct(){

		parent::__construct();
		$this->load->model('brand_model');

	}

	public function index(){
		$brand = $this->brand_model->listing();

		$data = array(	'title'		=> 'Data Brand',
						'isi'		=> 'admin/brand/list',
						'brand'	=> $brand);
		$this->load->view('admin/layout/wrapper',$data);

	}

	//Tambah Data
	public function tambah(){
		$this->form_validation->set_rules('nama_brand','Nama Brand','required|is_unique[brand.nama_brand]',
								array(		'required'	=> 'Nama brand harus diisi',
											'is_unique'	=> 'Nama brand sudah ada. Silahkan gunakan nama brand lain.'));
		if($this->form_validation->run()===FALSE){
			$data = array(	'title'	=>	'Tambah Brand',
							'isi'	=>	'admin/brand/tambah');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$slug_brand = url_title($this->input->post('nama_brand'),'dash',TRUE);
			$data = array(	'nama_brand'	=> $this->input->post('nama_brand'),
							'slug_brand'	=> $slug_brand);
			$this->brand_model->tambah($data);
			$this->session->set_flashdata('sukses','Data brand berhasil ditambah');
			redirect(base_url('admin/brand'));
		}
	}

	//Edit Data
	public function edit($id_brand){
		$brand = $this->brand_model->detail($id_brand);
		$this->form_validation->set_rules('nama_brand','Nama Brand','required|is_unique[brand.nama_brand]',
								array(		'required'	=> 'Nama brand harus diisi',
											'is_unique'	=>	'Nama brand sudah ada. Silahkan gunakan nama brand lain.'));
		
		if($this->form_validation->run()===FALSE){
			$data = array(	'title'		=>	'Edit Brand',
							'brand'	=>	$brand,
							'isi'		=>	'admin/brand/edit');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$slug_brand = url_title($this->input->post('nama_brand'),'dash',TRUE);
			$data = array(	'id_brand'	=> $id_brand,
							'nama_brand'	=> $this->input->post('nama_brand'),
							'slug_brand'	=> $slug_brand);
			$this->brand_model->edit($data);
			$this->session->set_flashdata('sukses','Data brand berhasil diedit');
			redirect(base_url('admin/brand'));
		}
	}

	//Delete data
	public function hapus($id_brand){
		$data = array('id_brand'=>$id_brand);
		$this->brand_model->delete($data);
		$this->session->set_flashdata('sukses','Data brand berhasil dihapus');
		redirect('admin/brand');
	}
}