<?php

class User extends CI_Controller {
	
	public function __construct(){

		parent::__construct();
		$this->load->model('user_model');

	}

	public function admin(){
		$user = $this->user_model->listing_admin();

		$data = array(	'title'		=> 'Data Admin',
						'isi'		=> 'admin/user/list',
						'user'	=> $user);
		$this->load->view('admin/layout/wrapper',$data);

	}

	public function user(){
		$user = $this->user_model->listing_user();

		$data = array(	'title'		=> 'Data User',
						'isi'		=> 'admin/user/list',
						'user'		=> $user);

		$this->load->view('admin/layout/wrapper',$data);
	}

	//Tambah Data
	public function tambah(){
		$this->form_validation->set_rules('nama_depan','Nama Lengkap','required',
								array(		'required'	=> 'Nama depan harus diisi'));
		$this->form_validation->set_rules('password','Password','required|min_length[8]|max_length[32]',
								array(		'required'		=>	'Password harus diisi',
											'min_length'	=>	'Password minimal 8 karakter',
											'max_length'	=>	'Password maksimal 32 karakter'));
		$this->form_validation->set_rules('username','Username','required|is_unique[users.username]',
								array(		'required'		=>	'Username harus diisi.',
											'is_unique'		=>	'Username sudah digunakaan.'));
		$this->form_validation->set_rules('password2','Konfirmasi Password','matches[password]',
								array(		'matches'		=>	'Password tidak sama'));
		$this->form_validation->set_rules('email','Email','valid_email|is_unique[users.email]',
								array(		'valid_email'	=>	'Masukkan email yang benar',
											'is_unique'		=>	'Email sudah terdaftar'));

		if($this->form_validation->run()===FALSE){
			$data = array(	'title'	=>	'Tambah Admin',
							'isi'	=>	'admin/user/tambah');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$data = array(	'nama_depan'	=>	$this->input->post('nama_depan'),
							'nama_belakang'	=>	$this->input->post('nama_belakang'),
							'password'		=>	sha1($this->input->post('password')),
							'username'		=>	$this->input->post('username'),
							'email'			=>	$this->input->post('email'),
							'akses_level'	=>	$this->input->post('akses'));
			$this->user_model->tambah($data);
			$this->session->set_flashdata('sukses','Admin berhasil ditambah');
			redirect(base_url('admin/user/admin'));
		}
	}

	//Edit Data
	public function edit($id_kategori){
		$kategori = $this->kategori_model->detail($id_kategori);
		$this->form_validation->set_rules('nama_kategori','Nama Kategori','required',
								array(		'required'	=> 'Nama kategori harus diisi'));
		
		if($this->form_validation->run()===FALSE){
			$data = array(	'title'		=>	'Edit Kategori',
							'kategori'	=>	$kategori,
							'isi'		=>	'admin/kategori/edit');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$slug_kategori = url_title($this->input->post('nama_kategori'),'dash',TRUE);
			$data = array(	'id_kategori'	=> $id_kategori,
							'nama_kategori'	=> $this->input->post('nama_kategori'),
							'keterangan'	=> $this->input->post('keterangan'),
							'slug_kategori'	=> $slug_kategori);
			$this->kategori_model->edit($data);
			$this->session->set_flashdata('sukses','Data kategori berhasil diedit');
			redirect(base_url('admin/kategori'));
		}
	}

	//Ganti Password
	public function gantipass($id_user){
		$user = $this->user_model->detail($id_user);
		$this->form_validation->set_rules('password_lama','Password Lama','required',
								array(		'required'	=> 'Password lama harus diisi'));
		$this->form_validation->set_rules('password_baru','Password Baru','required',
								array(		'required'	=> 'Password baru harus diisi'));
		$this->form_validation->set_rules('konfir_pass','Konfirmasi Password','matches[password_baru]',
								array(		'matches'	=> 'Password tidak sama'));
		

		if($this->form_validation->run()===FALSE){
			$data = array(	'title'		=>	'Ganti Password',
							'user'	=>	$user,
							'isi'		=>	'admin/user/gantipass');
			
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			if(sha1($this->input->post('password_lama'))!=$user->password){
				$this->session->set_flashdata('error','Password lama salah');
				redirect(base_url('admin/user/gantipass/'.$user->id_user));
			}else{
				$data = array(	'id_user'		=> $id_user,
								'password'		=> sha1($this->input->post('password_baru')));
				$this->user_model->edit($data);
				$this->session->set_flashdata('sukses','Password berhasil diubah');
				redirect(base_url('admin/user/admin'));
			}
		}
	}

	//Delete data
	public function hapus($id_user){
		$data = array('id_user'=>$id_user);
		$this->user_model->delete($data);
		$this->session->set_flashdata('sukses','Data User berhasil dihapus');
		redirect('admin/user/user');
	}
}