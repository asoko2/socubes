<?php

class Rubik extends CI_Controller {
	
	public function __construct(){

		parent::__construct();
		$this->load->model('rubik_model');
		$this->load->model('kategori_model');
		$this->load->model('brand_model');
	}

	public function index(){
		$rubik = $this->rubik_model->listing();

		$data = array(	'title'		=> 'Data Rubik',
						'isi'		=> 'admin/rubik/list',
						'rubik'	=> $rubik);
		$this->load->view('admin/layout/wrapper',$data);

	}

	//Tambah Data
	public function tambah(){
		$kategori 	= $this->kategori_model->listing();
		$brand 		= $this->brand_model->listing();

		$this->form_validation->set_rules('nama_produk','Nama Produk','required|is_unique[produk.nama_produk]',
								array(		'required'	=> 'Nama rubik harus diisi',
											'is_unique'	=> 'Nama rubik sudah ada. Silahkan gunakan nama rubik lain.'));
		$this->form_validation->set_rules('stok','Stok','required', array(	'required'	=> 'Stok harus diisi'));
		$this->form_validation->set_rules('harga','Harga','required', array(	'required'	=> 'Harga harus diisi'));

		if($this->form_validation->run()==FALSE){
			$data = array(	'title'		=>	'Tambah Rubik',
							'kategori'	=> $kategori,
							'brand'		=> $brand,
							'isi'		=>	'admin/rubik/tambah');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$config['upload_path']		= './assets/upload/gambar/';
			$config['allowed_types']	= 'gif|jpg|png';
			$config['max_size']			= '4096';
			

			$this->load->library('upload',$config);

			if(!$this->upload->do_upload('gambar')) {
				$data = array(	'title'		=>	'Tambah Data Rubik',
								'kategori'	=>	$kategori,
								'error'		=>	$this->upload->display_errors(),
								'brand'		=>	$brand,
								'isi'		=>	'admin/rubik/tambah');
				$this->load->view('admin/layout/wrapper',$data);
			}else{
				$upload_data = array(	'uploads'	=>$this->upload->data());

				$config['image_library']	= 'gd2';
				$config['source_image'] 	= './assets/upload/gambar/'.$upload_data['uploads']['file_name']; 
				$config['new_image'] 		= './assets/upload/gambar/thumbs/';
				$config['create_thumb'] 	= TRUE;
				$config['quality'] 			= "100%";
				$config['maintain_ratio'] 	= TRUE;
				$config['height'] 			= 400; // Pixel
				$config['x_axis'] 			= 0;
				$config['y_axis'] 			= 0;
				$config['thumb_marker'] 	= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();

				$slug_rubik = url_title($this->input->post('nama_produk'),'dash',TRUE);

				$data = array(	'nama_produk'	=> $this->input->post('nama_produk'),
								'gambar'		=> $upload_data['uploads']['file_name'],
								'id_kategori'		=> $this->input->post('id_kategori'),
								'id_brand'			=> $this->input->post('id_brand'),
								'stok'			=> $this->input->post('stok'),
								'harga'			=> $this->input->post('harga'),
								'deskripsi'		=> $this->input->post('deskripsi'),
								'slug_produk'	=> $slug_rubik);
				$this->rubik_model->tambah($data);
				$this->session->set_flashdata('sukses','Data rubik berhasil ditambah');
				redirect(base_url('admin/rubik'));
			}
		}
	}

	//Edit Data
	public function edit($id_produk){
		$rubik 		= $this->rubik_model->detail($id_produk);
		$kategori 	= $this->kategori_model->listing();
		$brand 		= $this->brand_model->listing();

		if($this->input->post('nama_produk')==$rubik->nama_produk){
			$this->form_validation->set_rules('nama_produk','Nama Produk','required',array('required'=>'Nama rubik harus diisi'));
		}else{
			$this->form_validation->set_rules('nama_produk','Nama Produk','required|is_unique[produk.nama_produk]',
									array(		'required'	=> 'Nama rubik harus diisi',
												'is_unique'	=> 'Nama rubik sudah ada. Silahkan gunakan nama rubik lain.'));
		}
		//$this->form_validation->set_rules('gambar','Gambar','required', array(	'required'	=> 'Pilih Gambar'));
		$this->form_validation->set_rules('stok','Stok','required', array(	'required'	=> 'Stok harus diisi'));
		$this->form_validation->set_rules('harga','Harga','required', array(	'required'	=> 'Harga harus diisi'));

		if($this->form_validation->run()==FALSE){
			$data = array(	'title'		=>	'Edit Data Rubik',
							'kategori'	=> $kategori,
							'brand'		=> $brand,
							'rubik'		=> $rubik,
							'isi'		=>	'admin/rubik/edit');
			$this->load->view('admin/layout/wrapper',$data);
		}else{

			if($_FILES['gambar']['name']!=''){
				$config['upload_path']		= './assets/upload/gambar/';
				$config['allowed_types']	= 'gif|jpg|png';
				$config['max_size']			= '4096';

				$this->load->library('upload',$config);

				if(!$this->upload->do_upload('gambar')) {
					$data = array(	'title'		=>	'Edit Data Rubik',
									'kategori'	=>	$kategori,
									'error'		=>	$this->upload->display_errors(),
									'brand'		=>	$brand,
									'isi'		=>	'admin/rubik/edit');
					$this->load->view('admin/layout/wrapper',$data);
				}else{
					// Hapus gambar lama
					if($rubik->gambar !=""){
						unlink('./assets/upload/gambar/'.$rubik->gambar);
						unlink('./assets/upload/gambar/thumbs/'.$rubik->gambar);
					}

					$upload_data = array(	'uploads'	=>$this->upload->data());
					$config['image_library']	= 'gd2';
					$config['source_image'] 	= './assets/upload/gambar/'.$upload_data['uploads']['file_name']; 
					$config['new_image'] 		= './assets/upload/gambar/thumbs/';
					$config['create_thumb'] 	= TRUE;
					$config['quality'] 			= "100%";
					$config['maintain_ratio'] 	= TRUE;
					$config['height'] 			= 400; // Pixel
					$config['x_axis'] 			= 0;
					$config['y_axis'] 			= 0;
					$config['thumb_marker'] 	= '';
					$this->load->library('image_lib', $config);
					$this->image_lib->resize();
					$slug_rubik = url_title($this->input->post('nama_produk'),'dash',TRUE);

					$data = array(	'id_produk'		=> $id_produk,
									'nama_produk'	=> $this->input->post('nama_produk'),
									'gambar'		=> $upload_data['uploads']['file_name'],
									'id_kategori'	=> $this->input->post('id_kategori'),
									'id_brand'		=> $this->input->post('id_brand'),
									'stok'			=> $this->input->post('stok'),
									'harga'			=> $this->input->post('harga'),
									'deskripsi'		=> $this->input->post('deskripsi'),
									'slug_produk'	=> $slug_rubik);
					$this->rubik_model->edit($data);
					$this->session->set_flashdata('sukses','Data rubik berhasil diedit');
					redirect(base_url('admin/rubik'));
				}
			}else{
				$slug_rubik = url_title($this->input->post('nama_produk'),'dash',TRUE);

				$data = array(	'id_produk'		=> $id_produk,
								'nama_produk'	=> $this->input->post('nama_produk'),
								'id_kategori'	=> $this->input->post('id_kategori'),
								'id_brand'		=> $this->input->post('id_brand'),
								'stok'			=> $this->input->post('stok'),
								'harga'			=> $this->input->post('harga'),
								'deskripsi'		=> $this->input->post('deskripsi'),
								'slug_produk'	=> $slug_rubik);
				$this->rubik_model->edit($data);
				$this->session->set_flashdata('sukses','Data rubik berhasil diedit');
				redirect(base_url('admin/rubik'));
			}
		}
	}

	//Delete data
	public function hapus($id_produk){
		$rubik = $this->rubik_model->detail($id_produk);
		// Hapus gambar
		if($rubik->gambar !=""){
			unlink('./assets/upload/gambar/'.$rubik->gambar);
			unlink('./assets/upload/gambar/thumbs/'.$rubik->gambar);
		}
		$data = array('id_produk'=>$id_produk);
		$this->rubik_model->delete($data);
		$this->session->set_flashdata('sukses','Data rubik berhasil dihapus');
		redirect('admin/rubik');
	}
}