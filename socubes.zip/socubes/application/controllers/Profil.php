<?php if (!defined('BASEPATH')) exit('No directs script access allowed');

class Profil extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){

		$user	=	$this->user_model->detail($this->session->userdata('id'));

		$data	=	array(	'title'		=>	'Profil Anda',
							'user'		=>	$user,
							'isi'		=>	'profil/list');

		$this->load->view('layout/wrapper',$data);
	}

	public function ubah(){

		$data 	=	array(	'id_user'		=>	$this->session->userdata('id'),
							'nama_depan'	=>	$this->input->post('nama_depan'),
							'nama_belakang'	=>	$this->input->post('nama_belakang'),
							'username'		=>	$this->input->post('username'),
							'email'			=>	$this->input->post('email'),
							'jk'			=>	$this->input->post('jk'));

		$this->user_model->edit($data);
		$this->session->set_flashdata('sukses','Profil behasil diubah');
		redirect(base_url('profil'));
	}

	public function ubahpassword(){
		$user	=	$this->user_model->detail($this->session->userdata('id'));

		$this->form_validation->set_rules(	'password_lama','Password Lama','required',
								array(		'required'	=>	'Password harus diisi'));
		$this->form_validation->set_rules(	'password_baru','Password Baru','required|min_length[8]|max_length[32]',
								array(		'required'	=>	'Password Baru harus diisi',
											'min_length'=>	'Password minimal 8 karakter',
											'max_length'=>	'Password maksimal 32 karakter'));
		$this->form_validation->set_rules(	'konfir_pass','Konfirmasi Password','required|matches[password_baru]',
								array(		'required'	=>	'Konfirmasi password harus diisi',
											'matches'	=>	'Password baru tidak sama'));

		if($this->form_validation->run()===FALSE){

			$data = array(	'title'		=>	'Ganti Password',
							'user'	=>	$user,
							'isi'		=>	'profil/list');
			
			$this->load->view('layout/wrapper',$data);

		}else{

			if(sha1($this->input->post('password_lama'))!=$user->password){

				$this->session->set_flashdata('error','Password lama salah');
				redirect(base_url('profil'));

			}else{
				
				$data = array(	'id_user'		=> $user->id_user,
								'password'		=> sha1($this->input->post('password_baru')));
				$this->user_model->edit($data);
				$this->session->set_flashdata('sukses','Password berhasil diubah');
				redirect(base_url('profil'));
			}
		}

	}

}