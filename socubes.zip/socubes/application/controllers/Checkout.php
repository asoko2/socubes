<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$user = $this->user_model->detail($this->session->userdata('id'));

		$data = array(	'title'		=>	'Checkout',
						'user'		=>	$user,
						'provinsi'	=>	$this->model_select->provinsi(),
						'isi'		=>	'checkout/list');

		$this->load->view('layout/wrapper',$data);
	}


	function ambil_data(){

		$modul=$this->input->post('modul');
		$id=$this->input->post('id');

		if($modul=="kabupaten"){

			echo $this->model_select->kabupaten($id);

		}else if($modul=="kecamatan"){

			echo $this->model_select->kecamatan($id);

		}else if($modul=="kelurahan"){

			echo $this->model_select->kelurahan($id);
		}

	}


	public function berhasil(){
		$data = array(	'title'	=>	'Checkout berhasil',
						'isi'	=>	'checkout/berhasil');
		$this->load->view('layout/wrapper',$data);
	}

	public function checkout(){
		$data	=	array(	'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'alamat'		=>	$this->input->post('alamat'),
							'penerima'		=>	$this->input->post('penerima'),
							'telp'			=>	$this->input->post('telepon'),
							'tanggal'		=>	$this->input->post('tanggal'),
							'total'			=>	$this->input->post('total'),
							'status'		=>	'1');

		$this->cart_model->checkout($data);
		$this->session->unset_userdata('id_transaksi');
		$data2 = array(	'title'	=>	'Checkout berhasil',
						'isi'	=>	'checkout/berhasil');
		$this->load->view('layout/wrapper',$data2);
	}

	public function detail(){
		$prov = $this->model_select->prov($this->input->post('provinsi'));
		$kab = $this->model_select->kab($this->input->post('kabupaten'));
		$kec = $this->model_select->kec($this->input->post('kecamatan'));
		$kel = $this->model_select->kel($this->input->post('kelurahan'));

		$id 	= $this->session->userdata('id_transaksi');

		$cart = $this->cart_model->listing($this->session->userdata('id_transaksi'));
		$count = $this->cart_model->total($this->session->userdata('id_transaksi'));

		$data = array(	'title'	=>	'Ringkasan Order',
						'isi'	=>	'checkout/ringkas',
						'cart'	=>	$cart,
						'count'	=>	$count,
						'nama'	=>	$this->input->post('nama_penerima'),
						'alamat'=>	$this->input->post('alamat'),
						'provinsi'	=>	$prov->name,
						'kabupaten'	=>	$kab->name,
						'kecamatan'	=>	$kec->name,
						'kelurahan'	=>	$kel->name,
						'telepon'	=>	$this->input->post('telepon'));
		$this->load->view('layout/wrapper',$data);

	}


	function getCity($province){		

		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "http://api.rajaongkir.com/starter/city?province=$province",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
		    "key: cb19e48f43e4a2dae1214ac556bcb658"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  //echo $response;
			$data = json_decode($response, true);
		  //echo json_encode($k['rajaongkir']['results']);

		  
		  for ($j=0; $j < count($data['rajaongkir']['results']); $j++){
		  

		    echo "<option value='".$data['rajaongkir']['results'][$j]['city_name']."'>".$data['rajaongkir']['results'][$j]['city_name']."</option>";
		  
		  }
		}
	}
}