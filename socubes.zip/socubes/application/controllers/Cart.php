<?php 

class Cart extends CI_Controller {

	var $CI = NULL;
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$id_transaksi = $this->session->userdata('id_transaksi');
		//$id = $id_transaksi['id_transaksi'];
		$cart = $this->cart_model->listing($this->session->userdata('id_transaksi'));
		$count = $this->cart_model->total($this->session->userdata('id_transaksi'));

		$data = array(	'title'	=>	'Keranjang Belanja | SoCubes',
						'cart'	=>	$cart,
						'count'	=>	$count,
						'isi'	=>	'cart/list');
		$this->load->view('layout/wrapper',$data);
	}

	public function baru(){
		$id_user 	= $this->session->userdata('id');
		$rubik		= $this->rubik_model->detail($this->input->post('id_produk'));
		$subtotal 	= $this->input->post('jumlah')*$rubik->harga;

		$data1 	= array(	'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'id_user'		=>	$id_user,
							'status'		=>	'0');

		$data	= array(	'id_produk'		=>	$this->input->post('id_produk'),
							'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'jumlah'		=>	$this->input->post('jumlah'),
							'subtotal'		=>	$subtotal);

		$this->cart_model->trans($data1);
		$this->cart_model->cart($data);
		$this->session->set_userdata('id_transaksi',$data1['id_transaksi']);
		redirect(base_url('cart'));
	}

	public function tambah(){
		$query=$this->db->get_where('cart',array(	'id_transaksi'	=>$this->input->post('id_transaksi'),
													'id_produk'		=>$this->input->post('id_produk')));

		$cek = $query->row();

		if($query->num_rows() > 0){
			$data = array(	'id_cart'	=>	$cek->id_cart,
							'jumlah'	=>	$this->input->post('jumlah') + $cek->jumlah);
			$this->cart_model->ubah($data);
			redirect(base_url('cart'));
		}else{
			$rubik		= $this->rubik_model->detail($this->input->post('id_produk'));
			$subtotal 	= $this->input->post('jumlah')*$rubik->harga;

			$data = array(	'id_produk'		=>	$this->input->post('id_produk'),
							'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'jumlah'		=>	$this->input->post('jumlah'),
							'subtotal'		=>	$subtotal);
			$data1 = array(		'id_produk'	=>	$this->input->post('id_produk'),
								'stok'	=>	$rubik->stok - $this->input->post('jumlah'));

			$this->cart_model->cart($data);
			$this->rubik_model->beli($data1);
			redirect(base_url('cart'));
		}
	}

	//Tambah Jumlah
	public function plus($id_cart){
		$jml = $this->input->post('jumlah');
		$jumlah = $jml + 1;
		$rubik = $this->rubik_model->detail($this->input->post('id_produk'));
		$sub = $rubik->harga * $jumlah;
		$data = array(	'id_cart'	=>	$id_cart,
						'id_produk'	=>	$rubik->id_produk,
						'jumlah'	=>	$jumlah,
						'subtotal'	=>	$sub);
		$data1 = array(	'id_produk'	=>	$rubik->id_produk,
						'stok'		=>	$rubik->stok - 1);
		$this->cart_model->ubah($data);
		$this->rubik_model->beli($data1);
		redirect(base_url('cart'));
	}

	//Kurangi Jumlah
	public function min($id_cart){
		$jml = $this->input->post('jumlah');
		$jumlah = $jml - 1;
		$rubik = $this->rubik_model->detail($this->input->post('id_produk'));
		$sub = $rubik->harga * $jumlah;
		$data = array(	'id_cart'	=>	$id_cart,
						'jumlah'	=>	$jumlah,
						'subtotal'	=>	$sub);

		$data1 = array(	'id_produk'	=>	$rubik->id_produk,
						'stok'		=>	$rubik->stok + 1);

		$this->cart_model->ubah($data);
		$this->rubik_model->beli($data1);
		redirect(base_url('cart'));
	}

	public function batal(){
		$rubik		= $this->rubik_model->detail($this->input->post('id_produk'));

		$data = array('id_cart'	=> $this->input->post('id_cart'));

		$data1 = array('id_produk' => $this->input->post('id_produk'),
						'stok'		=> $rubik->stok + $this->input->post('stok'));

		$this->cart_model->batal($data);
		$this->rubik_model->beli($data1);
		redirect(base_url('cart'));
	}

}