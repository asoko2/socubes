<?php

class Produk extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function kategori($slug_kategori){

	$kategori_data = $this->kategori_model->data($slug_kategori);

	$config['base_url']=base_url()."produk/kategori/".$slug_kategori."/";
        $config['total_rows']= $this->db->query("SELECT * FROM produk WHERE id_kategori = '".$kategori_data->id_kategori."' ;")->num_rows();
        $config['per_page']=9;
        $config['num_links'] = 2;
        $config['uri_segment']=5;

        //Tambahan untuk styling
        $config['full_tag_open'] = "<ul class='pagination'>";
        $config['full_tag_close'] ="</ul>";
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
        $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
        $config['next_tag_open'] = "<li>";
        $config['next_tagl_close'] = "</li>";
        $config['prev_tag_open'] = "<li>";
        $config['prev_tagl_close'] = "</li>";
        $config['first_tag_open'] = "<li>";
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = "<li>";
        $config['last_tagl_close'] = "</li>";
        
        $config['first_link']='< Pertama ';
        $config['last_link']='Terakhir > ';
        $config['next_link']='> ';
        $config['prev_link']='< ';
        $this->pagination->initialize($config);
		
		$rubik = $this->rubik_model->produk_kategori($config,$slug_kategori);
		$data = array(	'title'		=>	'SoCubes : '.$kategori_data->nama_kategori,
						'rubik'		=>	$rubik,
						'kategori_data'	=>	$kategori_data,
						'slug_kategori'	=>	$slug_kategori,
						'sidebar'	=>	'produk/kategori/sidebar',
						'isi'		=>	'produk/kategori/list');
		$this->load->view('layout/wrapper',$data);
	}

	public function cari(){
		$rubik = $this->rubik_model->cari($this->input->post('nama'));
		$cari = $this->input->post('nama');

		$data = array(	'rubik'	=>	$rubik,
						'cari'	=>	$cari,
						'title'	=>	'Pencarian : '.$this->input->post('nama'),
						'isi'	=>	'cari/list');
		$this->load->view('layout/wrapper',$data);

	}

	public function brand($slug_brand){
		$brand_data = $this->brand_model->data($slug_brand);

		$config['base_url']=base_url()."produk/brand/".$slug_brand."/";
        $config['total_rows']= $this->db->query("SELECT * FROM produk WHERE id_brand = '".$brand_data->id_brand."' ;")->num_rows();
        $config['per_page']=9;
        $config['num_links'] = 2;
        $config['uri_segment']=5;

        //Tambahan untuk styling
        $config['full_tag_open'] = "<ul class='pagination'>";
        $config['full_tag_close'] ="</ul>";
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
        $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
        $config['next_tag_open'] = "<li>";
        $config['next_tagl_close'] = "</li>";
        $config['prev_tag_open'] = "<li>";
        $config['prev_tagl_close'] = "</li>";
        $config['first_tag_open'] = "<li>";
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = "<li>";
        $config['last_tagl_close'] = "</li>";
        
        $config['first_link']='< Pertama ';
        $config['last_link']='Terakhir > ';
        $config['next_link']='> ';
        $config['prev_link']='< ';
        $this->pagination->initialize($config);

		$rubik = $this->rubik_model->produk_brand($config,$slug_brand);

		$data = array(	'title'		=>	'SoCubes :'.$brand_data->nama_brand,
						'rubik'		=>	$rubik,
						'brand_data'=>	$brand_data,
						'slug_brand'=>	$slug_brand,
						'sidebar'	=>	'produk/brand/sidebar',
						'isi'		=>	'produk/brand/list');
		$this->load->view('layout/wrapper',$data);
	}

	public function detail($slug_produk){
		$rubik = $this->rubik_model->detail_produk($slug_produk);
		$sama = $this->rubik_model->sama_kategori($rubik->id_kategori);
		$data 	=	array(	'title'		=>	$rubik->nama_produk,
							'rubik'		=>	$rubik,
							'sama'		=>	$sama,
							'isi'		=>	'produk/detail/list');
		$this->load->view('layout/wrapper',$data);
	}
}