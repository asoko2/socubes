<?php

class Daftar extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->form_validation->set_rules(	'nama_depan','Nama Depan','required',
								array(		'required'		=>	'Nama Depan harus diisi'));
		$this->form_validation->set_rules(	'email','Email','required|valid_email|is_unique[users.email]',
								array(		'valid_email'	=>	'Masukkan email yang valid.',
								'is_unique'		=>	'Email sudah terdaftar, silahkan login'));
		$this->form_validation->set_rules(	'username','Username','required|is_unique[users.username]',
								array(		'is_unique'		=>	'Username sudah digunakan.'));
		$this->form_validation->set_rules(	'password','Password','required|min_length[8]|max_length[32]',
								array(		'min_length'	=>	'Password minimal 8 karakter',
											'max_length'	=>	'Password maksimal 32 karakter'));
		$this->form_validation->set_rules(	'password2','Konfirmasi Password','required|matches[password]',
								array(		'matches'		=>	'Password tidak sama'));

		if($this->form_validation->run()==FALSE){
			$data = array(	'title'		=> 'Daftar',
						'isi'		=> 'new/daftar/list');
			$this->load->view('new/layout/wrapper',$data);
		}else{
			$data = array(	'nama_depan'	=> $this->input->post('nama_depan'),
							'nama_belakang'	=> $this->input->post('nama_belakang'),
							'email'			=> $this->input->post('email'),
							'username'		=> $this->input->post('username'),
							'password'		=> sha1($this->input->post('password')));
			$this->user_model->tambah($data);
			redirect('baru/daftar/sukses');
		}
	}

	public function sukses(){
		$data = array(	'title'		=>	'Sukses',
						'isi'		=>	'new/daftar/sukses');
		$this->load->view('new/layout/wrapper',$data);
	}
}