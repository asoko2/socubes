<?php

class Kontak extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$data	=	array(	'title'	=>	'Kontak',
							'isi'	=>	'new/kontak/list');
		$this->load->view('new/layout/wrapper',$data);
	}
}