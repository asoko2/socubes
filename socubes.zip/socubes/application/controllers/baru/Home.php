<?php 

class Home extends CI_Controller {

	public function __construct(){

		parent::__construct();

	}

	public function index(){
		$unggul		= $this->rubik_model->unggul();
		$rubik_baru = $this->rubik_model->rubik_baru();
		$rubik_home = $this->rubik_model->rubik_home();

		$data = array (	'title'		=>	'SoCubes | Toko Rubik Online Terpercaya di Indonesia',
						'unggul'		=>	$unggul,
						'rubik_baru'=>	$rubik_baru,
						'rubik_home'=>	$rubik_home,
						'isi'		=>	'new/home/list');
		$this->load->view('new/layout/wrapper',$data);
		
	}
}