<?php 

class Order extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$id 	=	$this->session->userdata('id');
		$trans = $this->cart_model->riwayat($this->session->userdata('id'));

		$data	=	array(	'title'	=>	'Riwayat Order',
							'trans'	=>	$trans,
							'isi'	=>	'order/list');
		$this->load->view('layout/wrapper',$data);
	}

	public function konfir(){
		$data	=	array(	'title'	=>	'Konfirmasi Pembayaran | SoCubes',
							'isi'	=>	'order/konfir');
		$this->load->view('layout/wrapper',$data);
	}

	public function konfirmasi(){
		$data 	=	array(	'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'no_rekening'	=>	$this->input->post('rekening'),
							'nama_rekening'	=>	$this->input->post('nama'),
							'nominal'		=>	$this->input->post('nominal'));

		$data1	=	array(	'id_transaksi'	=>	$this->input->post('id_transaksi'),
							'status'	=>	'2');

		$this->cart_model->konfir($data);
		$this->cart_model->bayar($data1);
		redirect(base_url('order'));
	}
}