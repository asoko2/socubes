<?php

class Brand_model extends CI_Model {

	public function __construct(){
		$this->load->database();
	}

	public function tambah($data){
		$this->db->insert('brand',$data);
	}

	public function listing(){
		$query=$this->db->get('brand');
		return $query->result();
	}

	public function detail($id_brand){
		$query=$this->db->get_where('brand',array('id_brand'=>$id_brand));
		return $query->row();
	}

	public function data($slug_brand){
		$query=$this->db->get_where('brand',array('slug_brand'=>$slug_brand));
		return $query->row();
	}

	public function edit($data){
		$this->db->where('id_brand',$data['id_brand']);
		$this->db->update('brand',$data);
	}

	public function delete($data){
		$this->db->where('id_brand',$data['id_brand']);
		$this->db->delete('brand',$data);
	}
}