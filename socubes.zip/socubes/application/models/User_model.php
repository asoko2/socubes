<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{

	public function __construct(){
		$this->load->database();
	}

	// Listing
	/*public function listing_user(){
		$this->db->select('users.*');
		$this->db->from('users');
		$this->db->order_by('id_user','DESC');
		$query = $this->db->get();
		return $query->result();
	}*/
	public function listing_user(){
		$query = $this->db->get_where('users', array('akses_level' => 'user'));
		return $query->result();
	}

	public function listing_admin(){
		$query = $this->db->get_where('users',array('akses_level' => 'admin'));
		return $query->result();
	}

	public function cekpass($id_user,$password){
		$query = $this->db->get_where('users',array(	'id_user'	=> $id_user,
														'password'	=> $password));
		return $query->num_row();
	}

	// Detail
	public function detail($id_user){
		$query = $this->db->get_where('users', array('id_user' => $id_user));
		return $query->row();
	}

	// Tambah
	public function tambah($data){
		$this->db->insert('users',$data);
	}

	// Edit
	public function edit($data){
		$this->db->where('id_user',$data['id_user']);
		$this->db->update('users',$data);
	}

	// Delete
	public function delete($data){
		$this->db->where('id_user',$data['id_user']);
		$this->db->delete('users',$data);
	}
}