<?php

class Cart_model extends CI_Model {

	public function __construct(){
		parent::__construct();
	}


	public function daftar(){
		$this->db->order_by('tanggal','DESC');
		$this->db->order_by('status','DESC');
		$this->db->order_by('id_transaksi','DESC');
		$query=$this->db->get('transaksi');
		return $query->result();
	}

	public function konfir($data){
		$this->db->insert('pembayaran',$data);
	}

	public function bayar($data){
		$this->db->where('id_transaksi',$data['id_transaksi']);
		$this->db->update('transaksi',$data);
	}

	public function list_bayar(){
		$this->db->select('pembayaran.*,transaksi.tanggal,transaksi.status');
		$this->db->from('pembayaran');
		$this->db->join('transaksi','transaksi.id_transaksi = pembayaran.id_transaksi','LEFT');
		$this->db->order_by('tanggal','DESC');
		$this->db->order_by('id_transaksi','DESC');
		$query = $this->db->get();
		return $query->result();
	}

	public function idbaru(){
		$this->db->select('id_transaksi');
		$this->db->from('transaksi');
		$this->db->order_by('id_transaksi','DESC');
		$query = $this->db->get();
		
		if($query->num_rows()>0){
			return $query->row();
		}else{
			return '0';
		}		
	}

	public function checkout($data){
		$this->db->where('id_transaksi',$data['id_transaksi']);
		$this->db->update('transaksi',$data);
	}

	public function hapus_sesi($data){
		$this->db->where('id_transaksi',$data['id_transaksi']);
		$this->db->delete('sesi_cart',$data);
	}
	public function trans($data1){
		$this->db->insert('transaksi',$data1);
	}

	public function cart($data){
		$this->db->insert('cart',$data);
	}
	
	public function ubah($data){
		$this->db->where('id_cart',$data['id_cart']);
		$this->db->update('cart',$data);
	}

	public function hitung($data){
		if($this->session->userdata('id_transaksi')==''){
			$this->db->where('id_transaksi',$data['id_transaksi']);
		}else{
			$this->db->where('id_transaksi',$data);
		}
		$this->db->from('cart');
		$query = $this->db->count_all_results();
		return $query;
	}

	public function listing($data){
		$this->db->select('*');
		$this->db->from('cart');
		if($this->session->userdata('id_transaksi')==''){
			$this->db->where('id_transaksi',$data['id_transaksi']);
		}else{
			$this->db->where('id_transaksi',$data);
		}
		$query = $this->db->get();
		return $query->result();
	}

	public function data($data){
		$this->db->select('*');
		$this->db->from('cart');
		$this->db->where('id_transaksi',$data);
		$query = $this->db->get();
		return $query->result();
	}

	public function riwayat($data){
		$this->db->select('*');
		$this->db->from('transaksi');
		$this->db->where('id_user',$data);
		$this->db->limit(10);
		$this->db->order_by('id_transaksi','DESC');
		$this->db->order_by('tanggal','DESC');
		$query = $this->db->get();
		return $query->result();
	}

	public function total($id_transaksi){
		$this->db->select_sum('subtotal');
		if($this->session->userdata('id_transaksi')==''){
			$this->db->where('id_transaksi',$id_transaksi['id_transaksi']);
		}else{
			$this->db->where('id_transaksi',$id_transaksi);
		}
		$this->db->from('cart');
		$query = $this->db->get();
		$hasil = $query->row();
		return $hasil->subtotal;
	}

	public function jumlah($id_transaksi){
		$this->db->select_sum('subtotal');
		$this->db->where('id_transaksi',$id_transaksi);
		$this->db->from('cart');
		$query = $this->db->get();
		$hasil = $query->row();
		return $hasil->subtotal;
	}

	public function batal($data){
		$this->db->where('id_cart',$data['id_cart']);
		$this->db->delete('cart',$data);
	}

}