<?php

class Rubik_model extends CI_Model {

	public function __construct(){
		$this->load->database();
	}

	public function tambah($data){
		$this->db->insert('produk',$data);
	}

	/*public function listing(){
		$this->db->select('produk.*, brand.nama_brand, kategori.nama_kategori');
		$this->db->from('produk');
		$this->db->join('brand','brand.id_brand = produk.id_brand','LEFT');
		$this->db->join('kategori','kategori.id_kategori = produk.id_kategori','LEFT');
		$this->db->order_by('id_produk','DESC');
		$query=$this->db->get();
		return $query->result();
	}*/

	public function listing(){
		$this->db->select('produk.*, brand.nama_brand, kategori.nama_kategori');
		$this->db->from('produk');
		$this->db->join('brand','brand.id_brand = produk.id_brand','LEFT');
		$this->db->join('kategori','kategori.id_kategori = produk.id_kategori','LEFT');
		$this->db->order_by('id_produk','DESC');
		$query=$this->db->get();
		return $query->result();			
	}

	public function cari($nama){
		$cari = $this->db->query('SELECT * FROM produk WHERE nama_produk LIKE "%'.$nama.'%"');
		return $cari->result();
	}

	/*public function produk_kategori($slug_kategori){
		$this->db->select('produk.*,kategori.slug_kategori');
		$this->db->where('kategori.slug_kategori', $slug_kategori);
		$this->db->from('produk');
		$this->db->join('kategori','kategori.id_kategori = produk.id_kategori','LEFT');
		$this->db->order_by('id_produk','DESC');
		$query=$this->db->get();
		return $query->result();			
	}*/

	/*public function produk_brand($slug_brand){
		$this->db->select('produk.*,brand.slug_brand');
		$this->db->where('brand.slug_brand', $slug_brand);
		$this->db->from('produk');
		$this->db->join('brand','brand.id_brand = produk.id_brand','LEFT');
		$this->db->order_by('id_produk','DESC');
		$query=$this->db->get();
		return $query->result();			
	}*/

	public function produk_kategori($config,$slug_kategori){
		$this->db->select('produk.*,kategori.slug_kategori');
		$this->db->where('kategori.slug_kategori',$slug_kategori);
		$this->db->join('kategori','kategori.id_kategori = produk.id_kategori','LEFT');
		$this->db->order_by('id_produk','DESC');
		$hasilquery=$this->db->get('produk', $config['per_page'], $this->uri->segment(5));
		/*if ($hasilquery->num_rows() > 0) {
            foreach ($hasilquery->result() as $value) {
                $data[]=$value;
            }
            return $data;
        }*/
		return $hasilquery->result();
	}

	public function produk_brand($config,$slug_brand){
		$this->db->select('produk.*,brand.slug_brand');
		$this->db->where('brand.slug_brand',$slug_brand);
		$this->db->join('brand','brand.id_brand = produk.id_brand','LEFT');
		$this->db->order_by('id_produk','DESC');
		$hasilquery=$this->db->get('produk', $config['per_page'], $this->uri->segment(5));
		/*if ($hasilquery->num_rows() > 0) {
            foreach ($hasilquery->result() as $value) {
                $data[]=$value;
            }
            return $data;
        }*/
		return $hasilquery->result();
	}

	public function sama_kategori($id_kategori){
		$this->db->select('*');
		$this->db->where('id_kategori',$id_kategori);
		$this->db->from('produk');
		$this->db->order_by('nama_produk','RANDOM');
		$this->db->limit(3);
		$query = $this->db->get();
		return $query->result();
	}


	public function rubik_home(){
		$this->db->select('produk.*');
		$this->db->from('produk');
		$this->db->order_by('id_produk','INC');
		$query = $this->db->get();
		return $query->row();
	}

	public function unggul(){
		$this->db->select('produk.*');
		$this->db->from('produk');
		$this->db->order_by('id_produk','DESC');
		$this->db->limit(4);
		$query = $this->db->get();
		return $query->result();
	}

	public function rubik_baru(){
		$this->db->select('produk.*');
		$this->db->from('produk');
		$this->db->order_by('id_produk','DESC');
		$this->db->limit(12);
		$query = $this->db->get();
		return $query->result();
	}

	public function detail($id_produk){
		$query=$this->db->get_where('produk',array('id_produk'=>$id_produk));
		return $query->row();
	}

	public function detail_produk($slug_produk){
		$query=$this->db->get_where('produk',array('slug_produk'=>$slug_produk));
		return $query->row();
	}

	public function beli($id){
		$this->db->where('id_produk',$id['id_produk']);
		$this->db->update('produk',$id);
	}

	public function edit($data){
		$this->db->where('id_produk',$data['id_produk']);
		$this->db->update('produk',$data);
	}

	public function delete($data){
		$this->db->where('id_produk',$data['id_produk']);
		$this->db->delete('produk',$data);
	}
}